"""Configurações editáveis pelo painel (contato, textos, parâmetros do MEI)."""
import json
import re
import unicodedata

from sqlalchemy.orm import Session

from .models import Setting

DEFAULTS: dict = {
    "business_name": "Natalice Alves",
    "business_subtitle": "Promoção de vendas",
    "headline": "Sua marca nas mãos de quem está comprando.",
    "intro": ("Degustação, distribuição de amostras, panfletagem e apoio no ponto de venda "
              "para marcas, distribuidoras e lojas que querem ser lembradas na hora da escolha."),
    "about": ("Sou Natalice Alves, promotora de vendas. Trabalho no lugar onde a compra acontece: "
              "o corredor do supermercado, a entrada da loja, o estande da feira. Meu trabalho é "
              "fazer o cliente parar, provar, conhecer o produto e levar para casa.\n\n"
              "Atendo como MEI, com nota fiscal, horário combinado e um relatório simples ao fim "
              "de cada ação, para você saber quantas pessoas foram abordadas e o que elas disseram."),
    "region": "Campinas e região – SP",
    "phone": "",
    "whatsapp": "",
    "email": "",
    "instagram": "",
    "cnpj": "59.794.471/0001-61",
    "legal_name": "59.794.471 NATALICE ALVES DA SILVA",
    "cnae": "7319-0/02 – Promoção de vendas",
    "opened_on": "2025-03-07",
    "mei_limits": {"2025": 81000, "2026": 81000, "2027": 110000},
    "das_default": 86.05,
    "hour_rate_hint": 0,
}

PUBLIC_KEYS = ("business_name", "business_subtitle", "headline", "intro", "about", "region",
               "phone", "whatsapp", "email", "instagram", "cnpj", "legal_name")


def get_all(db: Session) -> dict:
    data = dict(DEFAULTS)
    for row in db.query(Setting).all():
        try:
            data[row.key] = json.loads(row.value)
        except json.JSONDecodeError:
            data[row.key] = row.value
    return data


def get_public(db: Session) -> dict:
    all_ = get_all(db)
    return {k: all_[k] for k in PUBLIC_KEYS}


def update(db: Session, values: dict) -> dict:
    for key, value in values.items():
        if key not in DEFAULTS:
            continue
        row = db.get(Setting, key)
        encoded = json.dumps(value, ensure_ascii=False)
        if row:
            row.value = encoded
        else:
            db.add(Setting(key=key, value=encoded))
    db.commit()
    return get_all(db)


def slugify(text: str) -> str:
    text = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode()
    return re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-") or "item"

"""Esquemas Pydantic (validação de entrada e formato de saída da API)."""
import re
from datetime import date, datetime, time
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def _email(v: str) -> str:
    v = (v or "").strip().lower()
    if not EMAIL_RE.match(v):
        raise ValueError("Informe um e-mail válido.")
    return v


def _phone(v: str) -> str:
    digits = re.sub(r"\D", "", v or "")
    if len(digits) < 10 or len(digits) > 13:
        raise ValueError("Informe um telefone com DDD.")
    return v.strip()


class ORM(BaseModel):
    model_config = ConfigDict(from_attributes=True)


# ---------------------------------------------------------------- auth
class LoginIn(BaseModel):
    email: str
    password: str


class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: "UserOut"


class UserOut(ORM):
    id: int
    name: str
    email: str


class PasswordChange(BaseModel):
    current_password: str
    new_password: str = Field(min_length=8)


# ---------------------------------------------------------------- serviços
class ServiceIn(BaseModel):
    title: str = Field(min_length=2, max_length=120)
    summary: str = Field(min_length=2, max_length=255)
    description: str = ""
    includes: str = ""
    icon: str = "tag"
    position: int = 0
    active: bool = True


class ServiceOut(ORM):
    id: int
    title: str
    slug: str
    summary: str
    description: str
    includes: str
    icon: str
    position: int
    active: bool


# ---------------------------------------------------------------- portfólio
class PortfolioOut(ORM):
    id: int
    title: str
    brand: str
    service_id: int | None
    service: ServiceOut | None = None
    happened_on: date | None
    location: str
    description: str
    image_path: str | None
    featured: bool
    published: bool


# ---------------------------------------------------------------- depoimentos
class TestimonialIn(BaseModel):
    author: str = Field(min_length=2, max_length=120)
    company: str = Field("", max_length=120)
    text: str = Field(min_length=10, max_length=800)
    rating: int = Field(5, ge=1, le=5)
    website: str = ""        # honeypot (deve vir vazio)


class TestimonialOut(ORM):
    id: int
    author: str
    company: str
    text: str
    rating: int
    approved: bool
    created_at: datetime


# ---------------------------------------------------------------- contato
class ContactIn(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    email: str
    phone: str = ""
    message: str = Field(min_length=5, max_length=3000)
    consent: bool
    website: str = ""

    _v_email = field_validator("email")(_email)

    @field_validator("consent")
    @classmethod
    def _consent(cls, v):
        if not v:
            raise ValueError("É preciso autorizar o uso dos dados para responder seu contato.")
        return v


class ContactOut(ORM):
    id: int
    name: str
    email: str
    phone: str
    message: str
    read: bool
    created_at: datetime


# ---------------------------------------------------------------- orçamentos
QuoteStatus = Literal["novo", "em_analise", "proposta_enviada", "aprovado", "recusado"]


class QuoteIn(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    company: str = Field("", max_length=160)
    email: str
    phone: str
    service_id: int | None = None
    venue_type: str = Field("", max_length=60)
    city: str = Field("", max_length=120)
    event_date: date | None = None
    days: int = Field(1, ge=1, le=60)
    hours_per_day: int = Field(6, ge=1, le=12)
    details: str = Field("", max_length=3000)
    consent: bool
    website: str = ""

    _v_email = field_validator("email")(_email)
    _v_phone = field_validator("phone")(_phone)

    @field_validator("consent")
    @classmethod
    def _consent(cls, v):
        if not v:
            raise ValueError("É preciso autorizar o uso dos dados para receber o orçamento.")
        return v


class QuoteUpdate(BaseModel):
    status: QuoteStatus | None = None
    proposed_value: float | None = None
    admin_notes: str | None = None


class QuoteOut(ORM):
    id: int
    name: str
    company: str
    email: str
    phone: str
    service_id: int | None
    service: ServiceOut | None = None
    venue_type: str
    city: str
    event_date: date | None
    days: int
    hours_per_day: int
    details: str
    status: str
    proposed_value: float | None
    admin_notes: str
    client_id: int | None
    created_at: datetime


# ---------------------------------------------------------------- clientes
class ClientIn(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    company: str = ""
    document: str = ""
    email: str = ""
    phone: str = ""
    city: str = ""
    notes: str = ""

    @field_validator("email")
    @classmethod
    def _opt_email(cls, v):
        return _email(v) if v else ""


class ClientOut(ORM):
    id: int
    name: str
    company: str
    document: str
    email: str
    phone: str
    city: str
    notes: str
    created_at: datetime


class ClientDetail(ClientOut):
    total_actions: int = 0
    total_billed: float = 0


# ---------------------------------------------------------------- ações / agenda
ActionStatus = Literal["agendada", "confirmada", "realizada", "cancelada"]


class ActionIn(BaseModel):
    title: str = Field(min_length=2, max_length=160)
    client_id: int | None = None
    service_id: int | None = None
    quote_id: int | None = None
    date: date
    start_time: time | None = None
    end_time: time | None = None
    location: str = ""
    status: ActionStatus = "agendada"
    price: float = Field(0, ge=0)
    notes: str = ""
    report_people: int | None = Field(None, ge=0)
    report_samples: int | None = Field(None, ge=0)
    report_notes: str = ""


class ActionOut(ORM):
    id: int
    title: str
    client_id: int | None
    client: ClientOut | None = None
    service_id: int | None
    service: ServiceOut | None = None
    quote_id: int | None
    date: date
    start_time: time | None
    end_time: time | None
    location: str
    status: str
    price: float
    notes: str
    report_people: int | None
    report_samples: int | None
    report_notes: str


class ConvertQuoteIn(BaseModel):
    date: date
    title: str | None = None
    price: float | None = None
    location: str | None = None


# ---------------------------------------------------------------- financeiro
class FinanceIn(BaseModel):
    kind: Literal["receita", "despesa"]
    description: str = Field(min_length=2, max_length=200)
    category: str = ""
    amount: float = Field(gt=0)
    date: date
    status: Literal["pago", "pendente"] = "pago"
    payment_method: str = ""
    invoice_number: str = ""
    action_id: int | None = None
    client_id: int | None = None


class FinanceOut(ORM):
    id: int
    kind: str
    description: str
    category: str
    amount: float
    date: date
    status: str
    payment_method: str
    invoice_number: str
    action_id: int | None
    client_id: int | None
    client: ClientOut | None = None


class DasIn(BaseModel):
    amount: float = Field(ge=0)
    paid: bool
    paid_on: date | None = None


class DasOut(ORM):
    year: int
    month: int
    amount: float
    paid: bool
    paid_on: date | None


TokenOut.model_rebuild()

"""Rotas abertas, consumidas pelo site público."""
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session, selectinload

from ..database import get_db
from ..models import ContactMessage, PortfolioItem, Quote, Service, Testimonial
from ..schemas import (ContactIn, PortfolioOut, QuoteIn, ServiceOut, TestimonialIn,
                       TestimonialOut)
from ..security import form_limiter
from ..site_settings import get_public

router = APIRouter(prefix="/api/public", tags=["Site público"])


def _reject_bots(honeypot: str) -> None:
    if honeypot:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Não foi possível enviar.")


@router.get("/site")
def site_info(db: Session = Depends(get_db)):
    return get_public(db)


@router.get("/services", response_model=list[ServiceOut])
def services(db: Session = Depends(get_db)):
    return (db.query(Service).filter(Service.active.is_(True))
            .order_by(Service.position, Service.id).all())


@router.get("/services/{slug}", response_model=ServiceOut)
def service_detail(slug: str, db: Session = Depends(get_db)):
    svc = db.query(Service).filter(Service.slug == slug, Service.active.is_(True)).first()
    if not svc:
        raise HTTPException(404, "Serviço não encontrado.")
    return svc


@router.get("/portfolio", response_model=list[PortfolioOut])
def portfolio(featured: bool | None = None, service_id: int | None = None,
              db: Session = Depends(get_db)):
    q = (db.query(PortfolioItem).options(selectinload(PortfolioItem.service))
         .filter(PortfolioItem.published.is_(True)))
    if featured is not None:
        q = q.filter(PortfolioItem.featured.is_(featured))
    if service_id:
        q = q.filter(PortfolioItem.service_id == service_id)
    return q.order_by(PortfolioItem.happened_on.desc().nullslast(), PortfolioItem.id.desc()).all()


@router.get("/testimonials", response_model=list[TestimonialOut])
def testimonials(db: Session = Depends(get_db)):
    return (db.query(Testimonial).filter(Testimonial.approved.is_(True))
            .order_by(Testimonial.created_at.desc()).limit(12).all())


@router.post("/testimonials", status_code=201, dependencies=[Depends(form_limiter)])
def submit_testimonial(data: TestimonialIn, db: Session = Depends(get_db)):
    _reject_bots(data.website)
    db.add(Testimonial(**data.model_dump(exclude={"website"}), approved=False))
    db.commit()
    return {"message": "Obrigada! Sua avaliação será publicada depois de revisada."}


@router.post("/quotes", status_code=201, dependencies=[Depends(form_limiter)])
def submit_quote(data: QuoteIn, db: Session = Depends(get_db)):
    _reject_bots(data.website)
    if data.service_id and not db.get(Service, data.service_id):
        raise HTTPException(400, "Serviço inválido.")
    quote = Quote(**data.model_dump(exclude={"website"}))
    db.add(quote)
    db.commit()
    return {"id": quote.id,
            "message": "Pedido recebido. Você recebe o retorno em até 1 dia útil."}


@router.post("/contact", status_code=201, dependencies=[Depends(form_limiter)])
def submit_contact(data: ContactIn, db: Session = Depends(get_db)):
    _reject_bots(data.website)
    db.add(ContactMessage(**data.model_dump(exclude={"website", "consent"})))
    db.commit()
    return {"message": "Mensagem enviada. Respondo assim que possível."}

"""Painel: visão geral e histórico de atividades."""
from datetime import date, timedelta

from fastapi import APIRouter, Depends
from sqlalchemy import extract, func
from sqlalchemy.orm import Session, selectinload

from ..database import get_db
from ..deps import current_user
from ..models import (Action, AuditLog, ContactMessage, DasPayment, Quote, Testimonial)
from ..schemas import ActionOut, QuoteOut
from .finance import mei_status

router = APIRouter(prefix="/api/admin", tags=["Painel · Visão geral"], dependencies=[Depends(current_user)])


@router.get("/dashboard")
def dashboard(db: Session = Depends(get_db)):
    today = date.today()
    quotes_by_status = dict(db.query(Quote.status, func.count(Quote.id)).group_by(Quote.status).all())
    upcoming = (db.query(Action).options(selectinload(Action.client), selectinload(Action.service))
                .filter(Action.date >= today, Action.date <= today + timedelta(days=14),
                        Action.status.in_(["agendada", "confirmada"]))
                .order_by(Action.date, Action.start_time).limit(8).all())
    new_quotes = (db.query(Quote).options(selectinload(Quote.service)).filter(Quote.status == "novo")
                  .order_by(Quote.created_at.desc()).limit(5).all())
    done_year = (db.query(func.count(Action.id))
                 .filter(Action.status == "realizada", extract("year", Action.date) == today.year)
                 .scalar())
    people = db.query(func.coalesce(func.sum(Action.report_people), 0)).filter(
        Action.status == "realizada").scalar()

    das_this_month = db.query(DasPayment).filter_by(year=today.year, month=today.month).first()
    total_q = sum(quotes_by_status.values())
    approved = quotes_by_status.get("aprovado", 0)
    return {
        "quotes_by_status": quotes_by_status,
        "conversion_rate": round(approved / total_q * 100, 1) if total_q else 0,
        "new_quotes": [QuoteOut.model_validate(q).model_dump(mode="json") for q in new_quotes],
        "upcoming": [ActionOut.model_validate(a).model_dump(mode="json") for a in upcoming],
        "actions_done_year": done_year or 0,
        "people_reached": int(people or 0),
        "unread_messages": db.query(func.count(ContactMessage.id)).filter(ContactMessage.read.is_(False)).scalar(),
        "pending_testimonials": db.query(func.count(Testimonial.id)).filter(Testimonial.approved.is_(False)).scalar(),
        "mei": mei_status(db, today.year, today),
        "das_due": {"month": today.month, "year": today.year, "due_day": 20,
                    "paid": bool(das_this_month and das_this_month.paid)},
    }


@router.get("/audit")
def audit_log(limit: int = 50, db: Session = Depends(get_db)):
    rows = (db.query(AuditLog).options(selectinload(AuditLog.user))
            .order_by(AuditLog.created_at.desc(), AuditLog.id.desc()).limit(min(limit, 200)).all())
    return [{"id": r.id, "when": r.created_at.isoformat() if r.created_at else None,
             "user": r.user.name if r.user else "Sistema", "action": r.action, "entity": r.entity,
             "entity_id": r.entity_id, "summary": r.summary} for r in rows]

"""Painel: conteúdo do site (serviços, portfólio, depoimentos, mensagens, configurações)."""
import uuid
from datetime import date

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from sqlalchemy.orm import Session, selectinload

from ..config import settings
from ..database import get_db
from ..deps import audit, current_user, get_or_404
from ..models import ContactMessage, PortfolioItem, Service, Testimonial, User
from ..schemas import ContactOut, PortfolioOut, ServiceIn, ServiceOut, TestimonialOut
from .. import site_settings

router = APIRouter(prefix="/api/admin", tags=["Painel · Conteúdo"], dependencies=[Depends(current_user)])

IMAGE_SIGNATURES = {b"\xff\xd8\xff": ".jpg", b"\x89PNG": ".png", b"RIFF": ".webp"}


# ---------------------------------------------------------------- serviços
def _unique_slug(db: Session, title: str, exclude_id: int | None = None) -> str:
    base = site_settings.slugify(title)
    slug, n = base, 2
    while True:
        q = db.query(Service).filter(Service.slug == slug)
        if exclude_id:
            q = q.filter(Service.id != exclude_id)
        if not q.first():
            return slug
        slug, n = f"{base}-{n}", n + 1


@router.get("/services", response_model=list[ServiceOut])
def list_services(db: Session = Depends(get_db)):
    return db.query(Service).order_by(Service.position, Service.id).all()


@router.post("/services", response_model=ServiceOut, status_code=201)
def create_service(data: ServiceIn, db: Session = Depends(get_db), user: User = Depends(current_user)):
    svc = Service(**data.model_dump(), slug=_unique_slug(db, data.title))
    db.add(svc)
    db.flush()
    audit(db, user, "criou", "servico", svc.id, svc.title)
    db.commit()
    return svc


@router.put("/services/{sid}", response_model=ServiceOut)
def update_service(sid: int, data: ServiceIn, db: Session = Depends(get_db),
                   user: User = Depends(current_user)):
    svc = get_or_404(db, Service, sid, "Serviço")
    if data.title != svc.title:
        svc.slug = _unique_slug(db, data.title, sid)
    for k, v in data.model_dump().items():
        setattr(svc, k, v)
    audit(db, user, "editou", "servico", sid, svc.title)
    db.commit()
    return svc


@router.delete("/services/{sid}", status_code=204)
def delete_service(sid: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    svc = get_or_404(db, Service, sid, "Serviço")
    audit(db, user, "excluiu", "servico", sid, svc.title)
    db.delete(svc)
    db.commit()


# ---------------------------------------------------------------- portfólio
async def _save_image(file: UploadFile) -> str:
    content = await file.read()
    if len(content) > settings.MAX_UPLOAD_MB * 1024 * 1024:
        raise HTTPException(413, f"A imagem passa de {settings.MAX_UPLOAD_MB} MB. Reduza e envie de novo.")
    ext = next((e for sig, e in IMAGE_SIGNATURES.items() if content.startswith(sig)), None)
    if not ext or (ext == ".webp" and content[8:12] != b"WEBP"):
        raise HTTPException(415, "Envie uma imagem JPG, PNG ou WEBP.")
    name = f"{uuid.uuid4().hex}{ext}"
    (settings.UPLOAD_DIR / name).write_bytes(content)
    return f"/uploads/{name}"


def _remove_image(path: str | None) -> None:
    if path and path.startswith("/uploads/"):
        target = settings.UPLOAD_DIR / path.removeprefix("/uploads/")
        if target.is_file():
            target.unlink()


@router.get("/portfolio", response_model=list[PortfolioOut])
def list_portfolio(db: Session = Depends(get_db)):
    return (db.query(PortfolioItem).options(selectinload(PortfolioItem.service))
            .order_by(PortfolioItem.happened_on.desc().nullslast(), PortfolioItem.id.desc()).all())


@router.post("/portfolio", response_model=PortfolioOut, status_code=201)
async def create_portfolio(
    title: str = Form(..., min_length=2), brand: str = Form(""), service_id: int | None = Form(None),
    happened_on: date | None = Form(None), location: str = Form(""), description: str = Form(""),
    featured: bool = Form(False), published: bool = Form(True), image: UploadFile | None = File(None),
    db: Session = Depends(get_db), user: User = Depends(current_user),
):
    item = PortfolioItem(title=title, brand=brand, service_id=service_id or None, happened_on=happened_on,
                         location=location, description=description, featured=featured,
                         published=published)
    if image and image.filename:
        item.image_path = await _save_image(image)
    db.add(item)
    db.flush()
    audit(db, user, "criou", "portfolio", item.id, title)
    db.commit()
    db.refresh(item)
    return item


@router.put("/portfolio/{pid}", response_model=PortfolioOut)
async def update_portfolio(
    pid: int, title: str = Form(..., min_length=2), brand: str = Form(""),
    service_id: int | None = Form(None), happened_on: date | None = Form(None), location: str = Form(""),
    description: str = Form(""), featured: bool = Form(False), published: bool = Form(True),
    remove_image: bool = Form(False), image: UploadFile | None = File(None),
    db: Session = Depends(get_db), user: User = Depends(current_user),
):
    item = get_or_404(db, PortfolioItem, pid, "Item do portfólio")
    item.title, item.brand, item.service_id = title, brand, service_id or None
    item.happened_on, item.location, item.description = happened_on, location, description
    item.featured, item.published = featured, published
    if remove_image or (image and image.filename):
        _remove_image(item.image_path)
        item.image_path = None
    if image and image.filename:
        item.image_path = await _save_image(image)
    audit(db, user, "editou", "portfolio", pid, title)
    db.commit()
    db.refresh(item)
    return item


@router.delete("/portfolio/{pid}", status_code=204)
def delete_portfolio(pid: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    item = get_or_404(db, PortfolioItem, pid, "Item do portfólio")
    _remove_image(item.image_path)
    audit(db, user, "excluiu", "portfolio", pid, item.title)
    db.delete(item)
    db.commit()


# ---------------------------------------------------------------- depoimentos
@router.get("/testimonials", response_model=list[TestimonialOut])
def list_testimonials(db: Session = Depends(get_db)):
    return db.query(Testimonial).order_by(Testimonial.approved, Testimonial.created_at.desc()).all()


@router.patch("/testimonials/{tid}", response_model=TestimonialOut)
def moderate_testimonial(tid: int, approved: bool, db: Session = Depends(get_db),
                         user: User = Depends(current_user)):
    t = get_or_404(db, Testimonial, tid, "Avaliação")
    t.approved = approved
    audit(db, user, "editou", "avaliacao", tid, ("Aprovou " if approved else "Ocultou ") + t.author)
    db.commit()
    return t


@router.delete("/testimonials/{tid}", status_code=204)
def delete_testimonial(tid: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    t = get_or_404(db, Testimonial, tid, "Avaliação")
    audit(db, user, "excluiu", "avaliacao", tid, t.author)
    db.delete(t)
    db.commit()


# ---------------------------------------------------------------- mensagens de contato
@router.get("/messages", response_model=list[ContactOut])
def list_messages(db: Session = Depends(get_db)):
    return db.query(ContactMessage).order_by(ContactMessage.read, ContactMessage.created_at.desc()).all()


@router.patch("/messages/{mid}", response_model=ContactOut)
def mark_message(mid: int, read: bool = True, db: Session = Depends(get_db)):
    m = get_or_404(db, ContactMessage, mid, "Mensagem")
    m.read = read
    db.commit()
    return m


@router.delete("/messages/{mid}", status_code=204)
def delete_message(mid: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    m = get_or_404(db, ContactMessage, mid, "Mensagem")
    audit(db, user, "excluiu", "mensagem", mid, m.name)
    db.delete(m)
    db.commit()


# ---------------------------------------------------------------- configurações
@router.get("/settings")
def get_settings(db: Session = Depends(get_db)):
    return site_settings.get_all(db)


@router.put("/settings")
def put_settings(values: dict, db: Session = Depends(get_db), user: User = Depends(current_user)):
    audit(db, user, "editou", "configuracoes", None, ", ".join(sorted(values))[:200])
    return site_settings.update(db, values)

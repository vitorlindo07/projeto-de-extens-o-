"""Painel: agenda de ações promocionais."""
from datetime import date

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session, selectinload

from ..database import get_db
from ..deps import audit, current_user, get_or_404
from ..models import Action, FinanceEntry, User
from ..schemas import ActionIn, ActionOut, FinanceOut

router = APIRouter(prefix="/api/admin/actions", tags=["Painel · Agenda"], dependencies=[Depends(current_user)])


def _check_times(data: ActionIn) -> None:
    if data.start_time and data.end_time and data.end_time <= data.start_time:
        raise HTTPException(422, "O horário de término precisa ser depois do início.")


@router.get("", response_model=list[ActionOut])
def list_actions(start: date | None = None, end: date | None = None, status: str = "",
                 client_id: int | None = None, db: Session = Depends(get_db)):
    q = db.query(Action).options(selectinload(Action.client), selectinload(Action.service))
    if start:
        q = q.filter(Action.date >= start)
    if end:
        q = q.filter(Action.date <= end)
    if status:
        q = q.filter(Action.status == status)
    if client_id:
        q = q.filter(Action.client_id == client_id)
    return q.order_by(Action.date, Action.start_time).all()


@router.get("/{aid}", response_model=ActionOut)
def get_action(aid: int, db: Session = Depends(get_db)):
    return get_or_404(db, Action, aid, "Ação")


@router.post("", response_model=ActionOut, status_code=201)
def create_action(data: ActionIn, db: Session = Depends(get_db), user: User = Depends(current_user)):
    _check_times(data)
    a = Action(**data.model_dump())
    db.add(a)
    db.flush()
    audit(db, user, "criou", "acao", a.id, a.title)
    db.commit()
    db.refresh(a)
    return a


@router.put("/{aid}", response_model=ActionOut)
def update_action(aid: int, data: ActionIn, db: Session = Depends(get_db),
                  user: User = Depends(current_user)):
    _check_times(data)
    a = get_or_404(db, Action, aid, "Ação")
    for k, v in data.model_dump().items():
        setattr(a, k, v)
    audit(db, user, "editou", "acao", aid, f"{a.title} ({a.status})")
    db.commit()
    db.refresh(a)
    return a


@router.delete("/{aid}", status_code=204)
def delete_action(aid: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    a = get_or_404(db, Action, aid, "Ação")
    audit(db, user, "excluiu", "acao", aid, a.title)
    db.delete(a)
    db.commit()


@router.post("/{aid}/bill", response_model=FinanceOut, status_code=201)
def bill_action(aid: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    """Lança a receita da ação no financeiro (status pendente até o recebimento)."""
    a = get_or_404(db, Action, aid, "Ação")
    if a.price <= 0:
        raise HTTPException(422, "Defina o valor da ação antes de lançar a receita.")
    if db.query(FinanceEntry).filter(FinanceEntry.action_id == aid, FinanceEntry.kind == "receita").first():
        raise HTTPException(409, "A receita desta ação já foi lançada.")
    entry = FinanceEntry(kind="receita", description=a.title, category="Prestação de serviço",
                         amount=a.price, date=a.date, status="pendente", action_id=a.id,
                         client_id=a.client_id)
    db.add(entry)
    db.flush()
    audit(db, user, "criou", "financeiro", entry.id, f"Receita da ação #{aid}")
    db.commit()
    db.refresh(entry)
    return entry

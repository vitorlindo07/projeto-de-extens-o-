"""Painel: clientes e pedidos de orçamento."""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func, or_
from sqlalchemy.orm import Session, selectinload

from ..database import get_db
from ..deps import audit, current_user, get_or_404
from ..models import Action, Client, FinanceEntry, Quote, User
from ..schemas import (ActionOut, ClientDetail, ClientIn, ClientOut, ConvertQuoteIn, QuoteOut,
                       QuoteUpdate)

router = APIRouter(prefix="/api/admin", tags=["Painel · Comercial"], dependencies=[Depends(current_user)])


# ---------------------------------------------------------------- clientes
@router.get("/clients", response_model=list[ClientOut])
def list_clients(q: str = "", db: Session = Depends(get_db)):
    query = db.query(Client)
    if q:
        like = f"%{q}%"
        query = query.filter(or_(Client.name.ilike(like), Client.company.ilike(like),
                                 Client.email.ilike(like), Client.city.ilike(like)))
    return query.order_by(Client.company, Client.name).all()


@router.get("/clients/{cid}", response_model=ClientDetail)
def get_client(cid: int, db: Session = Depends(get_db)):
    c = get_or_404(db, Client, cid, "Cliente")
    out = ClientDetail.model_validate(c)
    out.total_actions = db.query(func.count(Action.id)).filter(Action.client_id == cid).scalar() or 0
    out.total_billed = (db.query(func.coalesce(func.sum(FinanceEntry.amount), 0))
                        .filter(FinanceEntry.client_id == cid, FinanceEntry.kind == "receita").scalar())
    return out


@router.get("/clients/{cid}/actions", response_model=list[ActionOut])
def client_actions(cid: int, db: Session = Depends(get_db)):
    return (db.query(Action).options(selectinload(Action.service))
            .filter(Action.client_id == cid).order_by(Action.date.desc()).all())


@router.post("/clients", response_model=ClientOut, status_code=201)
def create_client(data: ClientIn, db: Session = Depends(get_db), user: User = Depends(current_user)):
    c = Client(**data.model_dump())
    db.add(c)
    db.flush()
    audit(db, user, "criou", "cliente", c.id, c.company or c.name)
    db.commit()
    return c


@router.put("/clients/{cid}", response_model=ClientOut)
def update_client(cid: int, data: ClientIn, db: Session = Depends(get_db),
                  user: User = Depends(current_user)):
    c = get_or_404(db, Client, cid, "Cliente")
    for k, v in data.model_dump().items():
        setattr(c, k, v)
    audit(db, user, "editou", "cliente", cid, c.company or c.name)
    db.commit()
    return c


@router.delete("/clients/{cid}", status_code=204)
def delete_client(cid: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    c = get_or_404(db, Client, cid, "Cliente")
    audit(db, user, "excluiu", "cliente", cid, c.company or c.name)
    db.delete(c)
    db.commit()


# ---------------------------------------------------------------- orçamentos
@router.get("/quotes", response_model=list[QuoteOut])
def list_quotes(status: str = "", q: str = "", db: Session = Depends(get_db)):
    query = db.query(Quote).options(selectinload(Quote.service))
    if status:
        query = query.filter(Quote.status == status)
    if q:
        like = f"%{q}%"
        query = query.filter(or_(Quote.name.ilike(like), Quote.company.ilike(like),
                                 Quote.city.ilike(like), Quote.email.ilike(like)))
    return query.order_by(Quote.created_at.desc(), Quote.id.desc()).all()


@router.get("/quotes/{qid}", response_model=QuoteOut)
def get_quote(qid: int, db: Session = Depends(get_db)):
    return get_or_404(db, Quote, qid, "Orçamento")


@router.patch("/quotes/{qid}", response_model=QuoteOut)
def update_quote(qid: int, data: QuoteUpdate, db: Session = Depends(get_db),
                 user: User = Depends(current_user)):
    quote = get_or_404(db, Quote, qid, "Orçamento")
    for k, v in data.model_dump(exclude_unset=True).items():
        setattr(quote, k, v)
    audit(db, user, "editou", "orcamento", qid, f"Status: {quote.status}")
    db.commit()
    return quote


@router.delete("/quotes/{qid}", status_code=204)
def delete_quote(qid: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    quote = get_or_404(db, Quote, qid, "Orçamento")
    audit(db, user, "excluiu", "orcamento", qid, quote.name)
    db.delete(quote)
    db.commit()


@router.post("/quotes/{qid}/convert", response_model=ActionOut, status_code=201)
def convert_quote(qid: int, data: ConvertQuoteIn, db: Session = Depends(get_db),
                  user: User = Depends(current_user)):
    """Transforma um orçamento aprovado em cliente (se ainda não existir) + ação na agenda."""
    quote = get_or_404(db, Quote, qid, "Orçamento")
    if db.query(Action).filter(Action.quote_id == qid).first():
        raise HTTPException(409, "Este orçamento já virou uma ação na agenda.")

    client = quote.client
    if not client:
        client = db.query(Client).filter(Client.email == quote.email).first() if quote.email else None
    if not client:
        client = Client(name=quote.name, company=quote.company, email=quote.email,
                        phone=quote.phone, city=quote.city)
        db.add(client)
        db.flush()
        audit(db, user, "criou", "cliente", client.id, f"A partir do orçamento #{qid}")

    service_title = quote.service.title if quote.service else "Ação promocional"
    action = Action(
        title=data.title or f"{service_title} – {quote.company or quote.name}",
        client_id=client.id, service_id=quote.service_id, quote_id=qid, date=data.date,
        location=data.location if data.location is not None else quote.city,
        price=data.price if data.price is not None else (quote.proposed_value or 0),
        notes=quote.details, status="confirmada",
    )
    db.add(action)
    quote.client_id, quote.status = client.id, "aprovado"
    db.flush()
    audit(db, user, "criou", "acao", action.id, f"A partir do orçamento #{qid}")
    db.commit()
    db.refresh(action)
    return action

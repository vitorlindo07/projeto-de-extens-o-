"""Ponto de entrada da aplicação: API + site público + painel administrativo."""
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from starlette.exceptions import HTTPException as StarletteHTTPException

from .config import settings
from .database import Base, SessionLocal, engine
from .routers import agenda, auth, content, crm, dashboard, finance, public
from .seed import seed_base

PAGES = {
    "": "index.html", "servicos": "servicos.html", "portfolio": "portfolio.html",
    "sobre": "sobre.html", "orcamento": "orcamento.html", "contato": "contato.html",
    "avaliar": "avaliar.html", "privacidade": "privacidade.html",
    "admin": "admin/index.html", "admin/login": "admin/login.html",
}


@asynccontextmanager
async def lifespan(_: FastAPI):
    Base.metadata.create_all(engine)
    with SessionLocal() as db:
        seed_base(db)
    yield


app = FastAPI(
    title="Natalice Alves · Promoção de Vendas — API",
    description="API do site e do sistema de gestão (orçamentos, agenda, clientes, financeiro e MEI).",
    version="1.0.0",
    lifespan=lifespan,
)

if settings.CORS_ORIGINS:
    app.add_middleware(CORSMiddleware, allow_origins=settings.CORS_ORIGINS, allow_credentials=True,
                       allow_methods=["*"], allow_headers=["*"])


@app.middleware("http")
async def security_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("X-Frame-Options", "DENY")
    response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
    if request.url.path.startswith("/api/admin"):
        response.headers["Cache-Control"] = "no-store"
    return response


for r in (auth.router, public.router, content.router, crm.router, agenda.router, finance.router,
          dashboard.router):
    app.include_router(r)


@app.get("/api/health", tags=["Sistema"])
def health():
    return {"status": "ok"}


app.mount("/uploads", StaticFiles(directory=settings.UPLOAD_DIR), name="uploads")
app.mount("/assets", StaticFiles(directory=settings.FRONTEND_DIR / "assets"), name="assets")


@app.exception_handler(StarletteHTTPException)
async def not_found(request: Request, exc: StarletteHTTPException):
    if exc.status_code == 404 and not request.url.path.startswith("/api"):
        return FileResponse(settings.FRONTEND_DIR / "404.html", status_code=404)
    return JSONResponse({"detail": exc.detail}, status_code=exc.status_code, headers=getattr(exc, "headers", None))


@app.get("/{page:path}", include_in_schema=False)
def serve_page(page: str):
    page = page.strip("/").removesuffix(".html")
    if page in PAGES:
        return FileResponse(settings.FRONTEND_DIR / PAGES[page])
    raise StarletteHTTPException(404)

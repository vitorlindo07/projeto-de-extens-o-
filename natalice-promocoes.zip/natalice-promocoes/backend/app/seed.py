"""Dados iniciais.

    python -m app.seed           -> cria administradora e serviços (idempotente)
    python -m app.seed --demo    -> também cria dados FICTÍCIOS para demonstração/portfólio
                                    (não use --demo no site de produção)
"""
import sys
from datetime import date, time, timedelta

from sqlalchemy.orm import Session

from .config import settings
from .database import Base, SessionLocal, engine
from .models import (Action, Client, DasPayment, FinanceEntry, PortfolioItem, Quote, Service,
                     Testimonial, User)
from .security import hash_password
from .site_settings import slugify

SERVICES = [
    ("Degustação no ponto de venda", "Montagem da mesa, preparo das porções e abordagem do cliente no corredor.",
     "Para lançamentos e produtos que vendem melhor quando o cliente prova. Combino com a loja o melhor "
     "ponto e horário, preparo as porções seguindo as orientações da marca e conto quantas pessoas "
     "provaram e quantas levaram.",
     "Montagem e desmontagem da mesa\nPreparo e reposição das porções\nAbordagem e explicação do produto\n"
     "Relatório com público abordado e comentários", "cup"),
    ("Distribuição de amostras", "Entrega de sachês, miniaturas e brindes ao público certo.",
     "Amostras entregues na mão de quem compra a categoria, com uma frase curta sobre o produto e "
     "controle da quantidade distribuída.",
     "Controle de estoque das amostras\nAbordagem dirigida ao público-alvo\nContagem por turno", "gift"),
    ("Panfletagem", "Distribuição de folhetos, encartes e cupons em lojas, ruas e eventos.",
     "Panfletagem em frente a lojas, semáforos autorizados, feiras e eventos, com ponto e horário "
     "escolhidos pelo movimento.",
     "Escolha de ponto e horário\nDistribuição com abordagem\nRegistro em foto do local", "flyer"),
    ("Merchandising no PDV", "Organização de gôndola, cartazes, displays e materiais de ponto de venda.",
     "Deixo o produto visível e arrumado: frente de gôndola, preço sinalizado, display montado e "
     "material da marca no lugar certo.",
     "Abastecimento e frenteamento\nMontagem de displays e cartazes\nFotos de antes e depois", "shelf"),
    ("Apoio em feiras e eventos", "Recepção no estande, captação de contatos e ativação de marca.",
     "Atendimento no estande, entrega de material, cadastro de interessados e apoio em sorteios e "
     "ativações durante o evento.",
     "Recepção e atendimento no estande\nCadastro de interessados\nApoio em sorteios e ativações", "tent"),
    ("Demonstração de produto", "Mostro como o produto funciona, na frente de quem vai comprar.",
     "Para utilidades, cosméticos e eletroportáteis: demonstração ao vivo, respondendo dúvidas e "
     "levando o cliente até a gôndola.",
     "Treinamento com o material da marca\nDemonstração ao vivo\nRegistro das dúvidas mais comuns", "spark"),
]


def seed_base(db: Session) -> None:
    if not db.query(User).first():
        db.add(User(name=settings.ADMIN_NAME, email=settings.ADMIN_EMAIL.lower(),
                    password_hash=hash_password(settings.ADMIN_PASSWORD)))
    if not db.query(Service).first():
        for i, (title, summary, desc, includes, icon) in enumerate(SERVICES):
            db.add(Service(title=title, slug=slugify(title), summary=summary, description=desc,
                           includes=includes, icon=icon, position=i))
    db.commit()


def seed_demo(db: Session) -> None:
    """Dados fictícios só para demonstrar o sistema. Nomes de marcas são inventados."""
    if db.query(Client).first():
        print("Já existem clientes; demo ignorada.")
        return
    today = date.today()
    svc = {s.slug: s for s in db.query(Service).all()}
    clients = [
        Client(name="Paula Ramos", company="Café Serra Azul (exemplo)", email="paula@exemplo.com",
               phone="(19) 90000-0001", city="Campinas"),
        Client(name="Marcos Lima", company="Distribuidora Boa Mesa (exemplo)", email="marcos@exemplo.com",
               phone="(19) 90000-0002", city="Valinhos"),
        Client(name="Renata Souza", company="Agência Ponto Alto (exemplo)", email="renata@exemplo.com",
               phone="(19) 90000-0003", city="Vinhedo"),
    ]
    db.add_all(clients)
    db.flush()

    db.add_all([
        Quote(name="Juliana Prado", company="Laticínios Vale Verde (exemplo)", email="ju@exemplo.com",
              phone="(19) 90000-0010", service_id=svc["degustacao-no-ponto-de-venda"].id,
              venue_type="Supermercado", city="Campinas", event_date=today + timedelta(days=20), days=2,
              hours_per_day=6, details="Lançamento de iogurte grego, 2 lojas.", consent=True),
        Quote(name="Carlos Mendes", company="Feira Casa & Cia (exemplo)", email="carlos@exemplo.com",
              phone="(19) 90000-0011", service_id=svc["apoio-em-feiras-e-eventos"].id, venue_type="Feira",
              city="Valinhos", event_date=today + timedelta(days=35), days=3, hours_per_day=8,
              details="Recepção de estande.", status="proposta_enviada", proposed_value=1440, consent=True),
        Quote(name="Bruna Alves", email="bruna@exemplo.com", phone="(19) 90000-0012",
              service_id=svc["panfletagem"].id, venue_type="Rua / comércio", city="Campinas",
              details="Inauguração de loja.", status="recusado", consent=True),
    ])

    plan = [
        (-40, "Degustação de café – loja Centro", clients[0], "degustacao-no-ponto-de-venda", "realizada", 520, 310, 280),
        (-25, "Amostras de biscoito – fim de semana", clients[1], "distribuicao-de-amostras", "realizada", 680, 450, 900),
        (-12, "Gôndola e displays – rede regional", clients[1], "merchandising-no-pdv", "realizada", 400, None, None),
        (-5, "Panfletagem de inauguração", clients[2], "panfletagem", "realizada", 300, 600, 2000),
        (3, "Degustação de café – loja Taquaral", clients[0], "degustacao-no-ponto-de-venda", "confirmada", 520, None, None),
        (9, "Demonstração de air fryer", clients[2], "demonstracao-de-produto", "agendada", 610, None, None),
    ]
    for offset, title, client, slug, status, price, people, samples in plan:
        a = Action(title=title, client_id=client.id, service_id=svc[slug].id, date=today + timedelta(days=offset),
                   start_time=time(9), end_time=time(15), location=client.city, status=status, price=price,
                   report_people=people, report_samples=samples,
                   report_notes="Boa aceitação; público pediu tamanho família." if people else "")
        db.add(a)
        db.flush()
        if status == "realizada":
            db.add(FinanceEntry(kind="receita", description=title, category="Prestação de serviço",
                                amount=price, date=a.date, status="pago", payment_method="PIX",
                                action_id=a.id, client_id=client.id))
    db.add_all([
        FinanceEntry(kind="despesa", description="Avental e touca descartável", category="Material",
                     amount=86.40, date=today - timedelta(days=30)),
        FinanceEntry(kind="despesa", description="Transporte – aplicativo", category="Transporte",
                     amount=54.20, date=today - timedelta(days=12)),
    ])
    for m in range(1, today.month):
        db.add(DasPayment(year=today.year, month=m, amount=86.05, paid=True, paid_on=date(today.year, m, 18)))

    db.add(PortfolioItem(title="Degustação de café em supermercado (exemplo)", brand="Café Serra Azul",
                         service_id=svc["degustacao-no-ponto-de-venda"].id, happened_on=today - timedelta(days=40),
                         location="Campinas – SP", featured=True,
                         description="Dois dias de degustação com 310 pessoas abordadas."))
    db.add(Testimonial(author="Paula Ramos (exemplo)", company="Café Serra Azul", rating=5, approved=False,
                       text="Exemplo de avaliação para testar a moderação no painel."))
    db.commit()
    print("Dados de demonstração criados.")


def main() -> None:
    Base.metadata.create_all(engine)
    with SessionLocal() as db:
        seed_base(db)
        if "--demo" in sys.argv:
            seed_demo(db)
    print(f"Pronto. Login do painel: {settings.ADMIN_EMAIL}")


if __name__ == "__main__":
    main()

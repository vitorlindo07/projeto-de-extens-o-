"""Testes da API: site público, autenticação, fluxo comercial, financeiro/MEI e uploads."""
from datetime import date

from app.database import SessionLocal
from app.routers.finance import mei_status
from app import site_settings

QUOTE = {"name": "Ana Teste", "company": "Marca X", "email": "ana@teste.com", "phone": "(19) 99999-0000",
         "city": "Campinas", "days": 2, "hours_per_day": 6, "consent": True}


# ---------------------------------------------------------------- site público
def test_pages_and_public_data(client):
    assert client.get("/").status_code == 200
    assert client.get("/servicos").status_code == 200
    assert client.get("/admin/login").status_code == 200
    assert client.get("/nao-existe").status_code == 404
    site = client.get("/api/public/site").json()
    assert site["cnpj"] == "59.794.471/0001-61"
    assert "mei_limits" not in site            # dado interno não vaza no site
    services = client.get("/api/public/services").json()
    assert len(services) == 6 and services[0]["slug"] == "degustacao-no-ponto-de-venda"


def test_quote_validation(client):
    bad = {**QUOTE, "email": "invalido", "consent": False}
    r = client.post("/api/public/quotes", json=bad)
    assert r.status_code == 422
    assert client.post("/api/public/quotes", json={**QUOTE, "phone": "123"}).status_code == 422
    assert client.post("/api/public/quotes", json={**QUOTE, "website": "spam"}).status_code == 400  # honeypot


def test_testimonial_needs_approval(client, auth):
    r = client.post("/api/public/testimonials", json={"author": "Carla", "text": "Trabalho excelente!", "rating": 5})
    assert r.status_code == 201
    assert client.get("/api/public/testimonials").json() == []
    tid = client.get("/api/admin/testimonials", headers=auth).json()[0]["id"]
    client.patch(f"/api/admin/testimonials/{tid}?approved=true", headers=auth)
    assert len(client.get("/api/public/testimonials").json()) == 1


# ---------------------------------------------------------------- autenticação
def test_admin_requires_login(client):
    assert client.get("/api/admin/dashboard").status_code == 401
    assert client.get("/api/admin/dashboard", headers={"Authorization": "Bearer lixo"}).status_code == 401
    assert client.post("/api/auth/login", json={"email": "admin@natalice.com.br", "password": "errada"}).status_code == 401


def test_change_password(client, auth):
    r = client.post("/api/auth/password", headers=auth, json={"current_password": "Trocar@123", "new_password": "NovaSenha@2026"})
    assert r.status_code == 204
    assert client.post("/api/auth/login", json={"email": "admin@natalice.com.br", "password": "NovaSenha@2026"}).status_code == 200


# ---------------------------------------------------------------- fluxo comercial
def test_quote_to_action_to_revenue(client, auth):
    svc = client.get("/api/public/services").json()[0]
    qid = client.post("/api/public/quotes", json={**QUOTE, "service_id": svc["id"]}).json()["id"]

    client.patch(f"/api/admin/quotes/{qid}", headers=auth, json={"status": "proposta_enviada", "proposed_value": 900})
    action = client.post(f"/api/admin/quotes/{qid}/convert", headers=auth, json={"date": "2026-12-10"}).json()
    assert action["price"] == 900 and action["status"] == "confirmada"
    assert action["client"]["company"] == "Marca X"
    assert client.get(f"/api/admin/quotes/{qid}", headers=auth).json()["status"] == "aprovado"
    # converter de novo não duplica
    assert client.post(f"/api/admin/quotes/{qid}/convert", headers=auth, json={"date": "2026-12-10"}).status_code == 409

    entry = client.post(f"/api/admin/actions/{action['id']}/bill", headers=auth).json()
    assert entry["amount"] == 900 and entry["status"] == "pendente"
    assert client.post(f"/api/admin/actions/{action['id']}/bill", headers=auth).status_code == 409

    detail = client.get(f"/api/admin/clients/{action['client_id']}", headers=auth).json()
    assert detail["total_actions"] == 1 and detail["total_billed"] == 900


def test_action_time_validation(client, auth):
    r = client.post("/api/admin/actions", headers=auth, json={
        "title": "Teste", "date": "2026-12-01", "start_time": "15:00", "end_time": "09:00"})
    assert r.status_code == 422


def test_crud_client_and_search(client, auth):
    c = client.post("/api/admin/clients", headers=auth, json={"name": "João", "company": "Padaria Sol", "city": "Valinhos"}).json()
    assert client.get("/api/admin/clients?q=padaria", headers=auth).json()[0]["id"] == c["id"]
    client.put(f"/api/admin/clients/{c['id']}", headers=auth, json={"name": "João Silva", "company": "Padaria Sol"})
    assert client.get(f"/api/admin/clients/{c['id']}", headers=auth).json()["name"] == "João Silva"
    assert client.delete(f"/api/admin/clients/{c['id']}", headers=auth).status_code == 204
    assert client.get(f"/api/admin/clients/{c['id']}", headers=auth).status_code == 404


# ---------------------------------------------------------------- financeiro e MEI
def test_finance_summary_and_csv(client, auth):
    for kind, amount in (("receita", 1000), ("receita", 500), ("despesa", 120.5)):
        client.post("/api/admin/finance/entries", headers=auth, json={
            "kind": kind, "description": f"{kind} teste", "amount": amount, "date": "2026-03-15"})
    s = client.get("/api/admin/finance/summary?year=2026", headers=auth).json()
    assert s["receita"] == 1500 and s["despesa"] == 120.5 and s["saldo"] == 1379.5
    assert s["months"][2]["receita"] == 1500
    csv = client.get("/api/admin/finance/export.csv?year=2026", headers=auth)
    assert csv.status_code == 200 and "receita teste" in csv.text and "1000,00" in csv.text


def test_mei_proportional_limit(client):
    with SessionLocal() as db:
        # empresa aberta em 07/03/2025 → 10 meses de atividade em 2025
        m = mei_status(db, 2025, today=date(2025, 6, 1))
        assert m["proportional"] and m["active_months"] == 10 and m["limit"] == 67500
        m26 = mei_status(db, 2026, today=date(2026, 6, 1))
        assert m26["limit"] == 81000 and not m26["proportional"]


def test_mei_alert_levels(client, auth):
    client.post("/api/admin/finance/entries", headers=auth, json={
        "kind": "receita", "description": "Grande contrato", "amount": 70000, "date": "2026-02-01"})
    with SessionLocal() as db:
        assert mei_status(db, 2026, today=date(2026, 6, 1))["level"] == "atencao"
    client.post("/api/admin/finance/entries", headers=auth, json={
        "kind": "receita", "description": "Outro", "amount": 20000, "date": "2026-04-01"})
    with SessionLocal() as db:
        assert mei_status(db, 2026, today=date(2026, 6, 1))["level"] == "estourado"


def test_das_months_start_at_opening(client, auth):
    das25 = client.get("/api/admin/finance/das?year=2025", headers=auth).json()
    assert [d["month"] for d in das25] == list(range(3, 13))
    r = client.put("/api/admin/finance/das/2026/1", headers=auth, json={"amount": 86.05, "paid": True})
    assert r.json()["paid"] and r.json()["paid_on"]
    assert client.get("/api/admin/finance/das?year=2024", headers=auth).json() == []


def test_settings_update(client, auth):
    client.put("/api/admin/settings", headers=auth, json={"whatsapp": "(19) 98888-7777", "chave_invalida": "x"})
    assert client.get("/api/public/site").json()["whatsapp"] == "(19) 98888-7777"
    with SessionLocal() as db:
        assert "chave_invalida" not in site_settings.get_all(db)


# ---------------------------------------------------------------- uploads
PNG_1PX = (b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01\x08\x06\x00\x00\x00\x1f\x15\xc4\x89"
           b"\x00\x00\x00\rIDATx\x9cc\xf8\xff\xff?\x00\x05\xfe\x02\xfe\xa7\x35\x81\x84\x00\x00\x00\x00IEND\xaeB`\x82")


def test_portfolio_upload(client, auth):
    r = client.post("/api/admin/portfolio", headers=auth, data={"title": "Ação teste", "featured": "true"},
                    files={"image": ("foto.png", PNG_1PX, "image/png")})
    assert r.status_code == 201, r.text
    item = r.json()
    assert item["image_path"].startswith("/uploads/") and item["featured"]
    assert client.get(item["image_path"]).status_code == 200
    assert len(client.get("/api/public/portfolio?featured=true").json()) == 1
    # arquivo que não é imagem é recusado, mesmo com extensão .jpg
    bad = client.post("/api/admin/portfolio", headers=auth, data={"title": "Teste"},
                      files={"image": ("virus.jpg", b"MZ\x90\x00 nao sou imagem", "image/jpeg")})
    assert bad.status_code == 415
    assert client.delete(f"/api/admin/portfolio/{item['id']}", headers=auth).status_code == 204
    assert client.get(item["image_path"]).status_code == 404


def test_audit_log_records_actions(client, auth):
    client.post("/api/admin/clients", headers=auth, json={"name": "Registro"})
    log = client.get("/api/admin/audit", headers=auth).json()
    assert any(e["entity"] == "cliente" and e["action"] == "criou" for e in log)

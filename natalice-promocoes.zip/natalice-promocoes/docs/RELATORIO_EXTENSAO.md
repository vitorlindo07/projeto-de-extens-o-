# Relatório de Projeto de Extensão

> **Como usar este modelo:** os campos entre colchetes `[ ]` precisam ser preenchidos com os seus dados reais.
> A distribuição de horas abaixo é a planejada; ajuste cada linha às horas que você de fato registrar no diário
> de atividades, porque a coordenação pode pedir evidências (fotos, prints, atas, commits). Confira também o
> modelo oficial e as regras de horas do seu curso no AVA da UNIP.

## 1. Identificação

| | |
|---|---|
| Instituição | Universidade Paulista – UNIP |
| Curso | Análise e Desenvolvimento de Sistemas |
| Aluno | Erik [sobrenome] — RA [número] |
| Orientador(a) | [nome] |
| Título | Presença digital e sistema de gestão para microempreendedora de promoção de vendas |
| Carga horária | 252 horas |
| Período | [data de início] a [data de término] |
| Beneficiária | Natalice Alves da Silva — MEI, CNPJ 59.794.471/0001-61, CNAE 7319-0/02 (Promoção de vendas) |
| Local | [cidade] – SP |

## 2. Contexto e problema

A beneficiária é microempreendedora individual formalizada em março de 2025 e presta serviços de
promoção de vendas em supermercados, lojas e eventos: degustação, distribuição de amostras, panfletagem,
merchandising no ponto de venda e apoio em feiras.

No diagnóstico inicial foram identificados os seguintes problemas:

1. **Ausência de presença digital própria.** A divulgação dependia de indicação e de conversas avulsas no
   WhatsApp, sem um lugar para apresentar serviços, trabalhos anteriores e dados formais da empresa (CNPJ),
   que agências e marcas costumam pedir antes de contratar.
2. **Pedidos de orçamento sem padrão.** Faltavam informações básicas (data, cidade, duração), gerando várias
   trocas de mensagem até ser possível orçar.
3. **Agenda e cobranças controladas de memória ou em papel**, com risco de conflito de datas e de esquecer
   valores a receber.
4. **Risco fiscal do MEI.** Não havia acompanhamento do faturamento em relação ao limite anual (proporcional
   no ano de abertura), nem controle do pagamento mensal do DAS.

## 3. Objetivos

**Geral:** desenvolver e implantar uma solução web completa — site institucional e sistema de gestão — que
amplie a captação de clientes e organize a rotina administrativa e fiscal da beneficiária.

**Específicos:**
- Publicar um site responsivo com serviços, portfólio, avaliações e pedido de orçamento estruturado;
- Centralizar orçamentos, clientes e agenda em um painel acessível pelo celular;
- Controlar receitas, despesas, o limite de faturamento do MEI e o DAS mensal;
- Gerar relatório pós-ação para entregar aos clientes;
- Capacitar a beneficiária para usar o sistema com autonomia;
- Aplicar boas práticas de segurança e de proteção de dados (LGPD).

## 4. Público beneficiado e relevância social

Beneficiária direta: a microempreendedora. Beneficiários indiretos: as marcas, distribuidoras e lojas
contratantes, que passam a receber propostas e relatórios padronizados.

O projeto contribui com os Objetivos de Desenvolvimento Sustentável da ONU, especialmente o **ODS 8**
(trabalho decente e crescimento econômico), ao fortalecer a formalização e a sustentabilidade de um
pequeno negócio, e o **ODS 9** (indústria, inovação e infraestrutura), pela inclusão digital de uma
microempreendedora.

## 5. Metodologia

Desenvolvimento iterativo em ciclos curtos, com validação pela beneficiária ao fim de cada etapa:

1. Entrevistas e acompanhamento de uma ação real para entender o trabalho em campo;
2. Levantamento de requisitos em histórias de usuário e priorização;
3. Prototipação da interface e validação com a beneficiária;
4. Modelagem do banco de dados;
5. Implementação do back-end (API) e do front-end (site e painel);
6. Testes automatizados e testes de usabilidade com a beneficiária;
7. Implantação em servidor com HTTPS e backup;
8. Capacitação e entrega do manual de uso.

### Tecnologias
Python 3 e FastAPI (API REST), SQLAlchemy e SQLite (banco de dados relacional), HTML5, CSS3 e JavaScript
(front-end), JWT e bcrypt (autenticação), pytest (testes), Docker (implantação), Git (versionamento).

### Principais requisitos
| Código | Requisito |
|---|---|
| RF01 | Exibir serviços, portfólio e avaliações aprovadas no site |
| RF02 | Receber pedidos de orçamento em etapas, com consentimento LGPD |
| RF03 | Autenticar a administradora com e-mail e senha |
| RF04 | Gerenciar orçamentos por situação e convertê-los em ação na agenda |
| RF05 | Gerenciar agenda mensal de ações, com relatório pós-ação imprimível |
| RF06 | Cadastrar clientes e exibir histórico e total faturado |
| RF07 | Lançar receitas e despesas e exportar para planilha |
| RF08 | Calcular o faturamento contra o limite do MEI, inclusive proporcional |
| RF09 | Controlar o pagamento mensal do DAS |
| RF10 | Gerenciar o conteúdo do site (serviços, portfólio, avaliações, textos) |
| RNF01 | Funcionar em celular e computador (responsivo) |
| RNF02 | Senhas com hash, sessões com validade e limite de tentativas |
| RNF03 | Acessibilidade: navegação por teclado, contraste, rótulos em formulários |
| RNF04 | Registro de auditoria das alterações |

## 6. Cronograma e distribuição das 252 horas

| # | Etapa | Atividades | Horas |
|---|---|---|---:|
| 1 | Diagnóstico | Entrevistas com a beneficiária, acompanhamento de ação em campo, análise do CNAE e das obrigações do MEI, pesquisa de referências do setor | 20 |
| 2 | Requisitos e planejamento | Histórias de usuário, escopo, priorização, cronograma | 16 |
| 3 | Design e experiência | Identidade visual, wireframes, protótipo, validação com a beneficiária | 24 |
| 4 | Banco de dados | Modelo entidade-relacionamento, regras de integridade, dados iniciais | 12 |
| 5 | Back-end | API REST, autenticação, regras do MEI e do DAS, upload de imagens, segurança, auditoria | 60 |
| 6 | Front-end do site | 9 páginas, formulário de orçamento em etapas, responsividade, acessibilidade | 40 |
| 7 | Painel administrativo | 10 telas: visão geral, orçamentos, agenda, clientes, financeiro, conteúdo, configurações | 44 |
| 8 | Testes | Testes automatizados da API e testes de usabilidade com a beneficiária, correções | 14 |
| 9 | Implantação | Servidor, domínio, HTTPS, rotina de backup | 8 |
| 10 | Capacitação | Treinamento da beneficiária e manual do painel | 8 |
| 11 | Documentação | Documentação técnica e este relatório | 6 |
| | **Total** | | **252** |

Sugestão de distribuição: 14 semanas de aproximadamente 18 horas.

| Semanas | Etapas |
|---|---|
| 1–2 | 1, 2 |
| 3–4 | 3, 4 |
| 5–8 | 5 |
| 9–10 | 6 |
| 11–12 | 7 |
| 13 | 8, 9 |
| 14 | 10, 11 |

## 7. Resultados

- Site institucional publicado em [endereço], com [n] páginas e formulário de orçamento;
- Painel de gestão em uso pela beneficiária desde [data];
- [n] pedidos de orçamento recebidos pelo site no período de [datas];
- Controle do limite do MEI e do DAS disponível em tempo real;
- 15 testes automatizados cobrindo regras de negócio e segurança;
- Manual de uso entregue e capacitação realizada em [data], com duração de [n] horas.

[Inclua aqui prints das telas (pasta `docs/telas`), fotos da capacitação e o depoimento da beneficiária.]

## 8. Avaliação da beneficiária

[Transcreva ou anexe a avaliação da beneficiária sobre o projeto, com data e assinatura.]

## 9. Considerações finais

[Descreva o que aprendeu, as dificuldades encontradas (por exemplo: adequar a linguagem do painel a uma
usuária não técnica, tratar o limite proporcional do MEI) e os próximos passos possíveis: emissão de NFS-e
integrada, envio automático de e-mail ao receber orçamento, aplicativo instalável (PWA).]

## 10. Referências

- BRASIL. Lei Complementar nº 123, de 14 de dezembro de 2006 (Estatuto da Microempresa e Empresa de Pequeno Porte).
- BRASIL. Lei nº 13.709, de 14 de agosto de 2018 (Lei Geral de Proteção de Dados Pessoais).
- IBGE. Classificação Nacional de Atividades Econômicas – CNAE 2.3: subclasse 7319-0/02.
- Portal do Empreendedor (gov.br/mei).
- FASTAPI. Documentação oficial. https://fastapi.tiangolo.com
- SQLALCHEMY. Documentação oficial. https://docs.sqlalchemy.org
- W3C. Web Content Accessibility Guidelines (WCAG) 2.2.

---

Assinaturas

_______________________________ Aluno &nbsp;&nbsp;&nbsp;&nbsp; _______________________________ Beneficiária &nbsp;&nbsp;&nbsp;&nbsp; _______________________________ Orientador(a)

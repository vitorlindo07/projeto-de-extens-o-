# Modelo de dados

Banco relacional com 11 tabelas, definido em `backend/app/models.py` (SQLAlchemy 2.0).
As tabelas são criadas automaticamente na primeira execução.

```mermaid
erDiagram
    users ||--o{ audit_logs : "registra"
    services ||--o{ quotes : "solicitado em"
    services ||--o{ actions : "executado em"
    services ||--o{ portfolio_items : "ilustra"
    clients ||--o{ quotes : "origina"
    clients ||--o{ actions : "contrata"
    clients ||--o{ finance_entries : "paga"
    quotes ||--o| actions : "vira"
    actions ||--o{ finance_entries : "gera receita"

    users {
        int id PK
        string name
        string email UK
        string password_hash
        bool is_active
        datetime last_login
    }
    settings {
        string key PK
        text value "JSON"
    }
    audit_logs {
        int id PK
        int user_id FK
        string action
        string entity
        int entity_id
        string summary
        datetime created_at
    }
    services {
        int id PK
        string title
        string slug UK
        string summary
        text description
        text includes
        string icon
        int position
        bool active
    }
    portfolio_items {
        int id PK
        string title
        string brand
        int service_id FK
        date happened_on
        string location
        text description
        string image_path
        bool featured
        bool published
    }
    testimonials {
        int id PK
        string author
        string company
        text text
        int rating
        bool approved
    }
    contact_messages {
        int id PK
        string name
        string email
        string phone
        text message
        bool read
    }
    clients {
        int id PK
        string name
        string company
        string document
        string email
        string phone
        string city
        text notes
    }
    quotes {
        int id PK
        string name
        string company
        string email
        string phone
        int service_id FK
        string venue_type
        string city
        date event_date
        int days
        int hours_per_day
        text details
        string status
        float proposed_value
        text admin_notes
        bool consent
        int client_id FK
    }
    actions {
        int id PK
        string title
        int client_id FK
        int service_id FK
        int quote_id FK
        date date
        time start_time
        time end_time
        string location
        string status
        float price
        text notes
        int report_people
        int report_samples
        text report_notes
    }
    finance_entries {
        int id PK
        string kind
        string description
        string category
        float amount
        date date
        string status
        string payment_method
        string invoice_number
        int action_id FK
        int client_id FK
    }
    das_payments {
        int id PK
        int year
        int month
        float amount
        bool paid
        date paid_on
    }
```

## Situações (estados)

| Entidade | Valores | Fluxo típico |
|---|---|---|
| Orçamento (`quotes.status`) | novo, em_analise, proposta_enviada, aprovado, recusado | novo → em_analise → proposta_enviada → aprovado (vira ação) |
| Ação (`actions.status`) | agendada, confirmada, realizada, cancelada | confirmada → realizada (preenche relatório e lança receita) |
| Lançamento (`finance_entries.status`) | pago, pendente | pendente → pago quando o cliente paga |

## Regras de negócio no banco e na API

- **Limite do MEI**: soma das receitas do ano em `finance_entries`, comparada ao limite do ano em
  `settings.mei_limits`. No ano de abertura (`settings.opened_on`) o limite é proporcional:
  limite ÷ 12 × meses de atividade. Alertas em 80% e 100%; a faixa de tolerância de 20% é exibida.
- **DAS**: um registro por mês em `das_payments` (único por ano+mês); meses anteriores à abertura não aparecem.
- **Conversão de orçamento**: cria (ou reaproveita, pelo e-mail) o cliente, cria a ação como confirmada e marca o
  orçamento como aprovado. Um orçamento só pode virar uma ação.
- **Receita da ação**: cada ação gera no máximo uma receita (`action_id`), lançada como pendente.
- Exclusões de cliente/serviço não apagam histórico: as chaves estrangeiras usam `ON DELETE SET NULL`.

# Manual do painel

Guia rápido para o dia a dia. Acesse **seusite.com.br/admin** e entre com seu e-mail e senha.

## Primeiro acesso
1. Entre com a senha inicial e vá em **Configurações → Trocar senha**.
2. Ainda em **Configurações**, preencha WhatsApp, e-mail, Instagram e a região que você atende.
   O botão de WhatsApp do site só aparece depois que o número é preenchido.
3. Revise os textos da página inicial e da página Sobre.

## Quando chega um pedido de orçamento
1. O número ao lado de **Orçamentos** mostra quantos pedidos novos existem.
2. Abra o pedido, clique em **Responder no WhatsApp** (a mensagem já vem pronta).
3. Ao enviar a proposta, mude a situação para **Proposta enviada** e anote o valor.
4. Se o cliente aprovar, clique em **Transformar em ação**: o cliente é cadastrado e a ação entra na agenda.

## Antes e depois de cada ação
- Na **Agenda**, clique na ação para conferir horário e local.
- Depois da ação, preencha **Relatório pós-ação** (pessoas abordadas, amostras, comentários),
  mude a situação para **Realizada** e use **Imprimir relatório** para enviar ao cliente em PDF.
- Clique em **Lançar receita**: o valor vai para o financeiro como pendente. Quando receber, abra o
  lançamento e marque **Recebido**; anote o número da nota fiscal.

## Financeiro e MEI
- O medidor mostra quanto você já faturou no ano e quanto falta para o limite do MEI.
  Em amarelo (acima de 80%), planeje as próximas ações; em vermelho, fale com uma contadora.
- No quadro **DAS mensal**, clique no mês para marcar como pago. O DAS vence todo dia 20.
- Em maio, a visão geral lembra da **declaração anual (DASN-SIMEI)**. Use o total de receitas do ano anterior.
- **Exportar planilha** gera um arquivo que abre no Excel ou Google Planilhas.

## Site
- **Portfólio**: adicione fotos das ações (JPG/PNG até 5 MB). Marque "Destacar" para aparecer na página inicial.
  Peça autorização da loja e da marca antes de publicar fotos com pessoas ou produtos.
- **Avaliações**: envie o link `/avaliar` para quem contratou. Você decide o que publicar.
- **Serviços**: edite textos, ordem e o que está incluído. Desmarque "Mostrar no site" para ocultar.

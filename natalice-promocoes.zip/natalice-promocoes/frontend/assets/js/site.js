/* Site público — cabeçalho/rodapé compartilhados, ícones e lógica de cada página. */
const API = "/api/public";

export const ICONS = {
  cup: '<path d="M6 9h11v5a5 5 0 0 1-5 5h-1a5 5 0 0 1-5-5z"/><path d="M17 10h1.5a2.5 2.5 0 0 1 0 5H17"/><path d="M9 3c-.8 1 .8 2 0 3M12.5 3c-.8 1 .8 2 0 3"/>',
  gift: '<rect x="4" y="9" width="16" height="11" rx="1"/><path d="M3 9h18M12 9v11M12 9c-2-4-6-4-6-1.5S10 9 12 9zm0 0c2-4 6-4 6-1.5S14 9 12 9z"/>',
  flyer: '<path d="M6 3h9l4 4v14H6z"/><path d="M15 3v4h4M9 11h7M9 14h7M9 17h4"/>',
  shelf: '<path d="M3 20h18M3 13h18M5 13V6h4v7M11 13V8h3v5M16 13V5h3v8M6 20v-4h3v4M12 20v-5h5v5"/>',
  tent: '<path d="M3 20 12 5l9 15z"/><path d="M12 5v15M9 20l3-5 3 5"/>',
  spark: '<path d="M12 3v4M12 17v4M3 12h4M17 12h4M6 6l2.5 2.5M15.5 15.5 18 18M6 18l2.5-2.5M15.5 8.5 18 6"/><circle cx="12" cy="12" r="2"/>',
  tag: '<path d="M3 12V4h8l10 10-8 8z"/><circle cx="7.5" cy="8.5" r="1.5"/>',
  photo: '<rect x="3" y="5" width="18" height="14" rx="1"/><circle cx="9" cy="10" r="2"/><path d="m21 16-5-5-8 8"/>',
  whats: '<path d="M4 20l1.3-3.9A8 8 0 1 1 8 18.8z"/><path d="M9 9.5c.3 2 1.8 3.8 4 4.5l1.2-1.2 2 1-.5 1.5c-3.3.3-7.2-3.2-7.2-6.8L10 8l1 2z"/>',
  menu: '<path d="M4 7h16M4 12h16M4 17h16"/>',
  close: '<path d="M6 6l12 12M18 6 6 18"/>',
};

export function icon(name, cls = "") {
  return `<svg class="${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"
    stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[name] || ICONS.tag}</svg>`;
}

export const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) =>
  ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

export async function api(path, options = {}) {
  const res = await fetch(API + path, {
    headers: { "Content-Type": "application/json" }, ...options,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const detail = Array.isArray(data.detail)
      ? data.detail.map((d) => d.msg.replace(/^Value error, /, "")).join(" ")
      : data.detail;
    throw new Error(detail || "Não foi possível enviar. Verifique sua conexão e tente de novo.");
  }
  return data;
}

const fmtDate = (iso) => iso ? new Date(iso + "T12:00:00").toLocaleDateString("pt-BR", { month: "long", year: "numeric" }) : "";
const whatsLink = (num, text = "Olá, Natalice! Vim pelo site e quero falar sobre uma ação promocional.") =>
  `https://wa.me/55${String(num).replace(/\D/g, "").replace(/^55/, "")}?text=${encodeURIComponent(text)}`;

/* ---------------------------------------------------------------- moldura */
const NAV = [
  ["/", "Início"], ["/servicos", "Serviços"], ["/portfolio", "Portfólio"],
  ["/sobre", "Sobre"], ["/contato", "Contato"],
];

function renderHeader(site) {
  const el = document.querySelector("[data-header]");
  if (!el) return;
  const path = location.pathname.replace(/\.html$/, "").replace(/\/index$/, "/") || "/";
  el.className = "site-header";
  el.innerHTML = `
    <div class="wrap">
      <a class="brand" href="/" aria-label="${esc(site.business_name)}, página inicial">
        <span class="brand-mark" aria-hidden="true">${esc(site.business_name[0] || "N")}</span>
        <span class="brand-name"><strong>${esc(site.business_name)}</strong><span>${esc(site.business_subtitle)}</span></span>
      </a>
      <button class="menu-toggle" aria-expanded="false" aria-controls="nav" aria-label="Abrir menu">${icon("menu")}</button>
      <nav class="nav" id="nav" aria-label="Principal">
        ${NAV.map(([href, label]) => `<a href="${href}" ${path === href ? 'aria-current="page"' : ""}>${label}</a>`).join("")}
        <a class="btn btn-tag" href="/orcamento">Pedir orçamento</a>
      </nav>
    </div>`;
  const toggle = el.querySelector(".menu-toggle");
  const nav = el.querySelector(".nav");
  toggle.addEventListener("click", () => {
    const open = nav.classList.toggle("open");
    toggle.setAttribute("aria-expanded", open);
    toggle.innerHTML = icon(open ? "close" : "menu");
  });
}

function renderFooter(site) {
  const el = document.querySelector("[data-footer]");
  if (!el) return;
  el.className = "site-footer";
  const contacts = [
    site.whatsapp && `<li>WhatsApp: <a href="${whatsLink(site.whatsapp)}" target="_blank" rel="noopener">${esc(site.whatsapp)}</a></li>`,
    site.phone && `<li>Telefone: <a href="tel:${esc(site.phone.replace(/\D/g, ""))}">${esc(site.phone)}</a></li>`,
    site.email && `<li>E-mail: <a href="mailto:${esc(site.email)}">${esc(site.email)}</a></li>`,
    site.instagram && `<li>Instagram: <a href="https://instagram.com/${esc(site.instagram.replace("@", ""))}" target="_blank" rel="noopener">${esc(site.instagram)}</a></li>`,
  ].filter(Boolean).join("") || `<li><a href="/contato">Formulário de contato</a></li>`;
  el.innerHTML = `
    <div class="wrap">
      <div class="footer-grid">
        <div>
          <h2>${esc(site.business_name)} · ${esc(site.business_subtitle)}</h2>
          <p>Degustação, amostras, panfletagem e apoio no ponto de venda. Atendimento em ${esc(site.region)}.</p>
        </div>
        <div><h2>Contato</h2><ul>${contacts}</ul></div>
        <div><h2>Navegação</h2><ul>
          <li><a href="/servicos">Serviços</a></li><li><a href="/portfolio">Portfólio</a></li>
          <li><a href="/orcamento">Pedir orçamento</a></li><li><a href="/avaliar">Avaliar um trabalho</a></li>
          <li><a href="/privacidade">Privacidade</a></li>
        </ul></div>
      </div>
      <div class="footer-legal">
        <span>${esc(site.legal_name)} · CNPJ ${esc(site.cnpj)}</span>
        <span>© ${new Date().getFullYear()} · <a href="/admin">Área restrita</a></span>
      </div>
    </div>`;
  if (site.whatsapp && !document.querySelector(".whats-float")) {
    document.body.insertAdjacentHTML("beforeend",
      `<a class="whats-float" href="${whatsLink(site.whatsapp)}" target="_blank" rel="noopener" aria-label="Conversar no WhatsApp">${icon("whats")}</a>`);
  }
}

/* ---------------------------------------------------------------- formulários */
function formData(form) {
  const data = {};
  for (const [k, v] of new FormData(form)) data[k] = v;
  form.querySelectorAll('input[type="checkbox"]').forEach((c) => { data[c.name] = c.checked; });
  return data;
}

function showNotice(box, kind, text) {
  box.hidden = false;
  box.className = `notice ${kind}`;
  box.textContent = text;
  box.setAttribute("tabindex", "-1");
  box.focus();
}

function validate(form) {
  let first = null;
  form.querySelectorAll(".field").forEach((f) => {
    f.classList.remove("invalid");
    f.querySelector(".error")?.remove();
  });
  form.querySelectorAll("[required]").forEach((input) => {
    if (input.closest("[hidden]")) return;
    const ok = input.type === "checkbox" ? input.checked : input.checkValidity() && input.value.trim();
    if (!ok) {
      const field = input.closest(".field") || input.closest(".check");
      field?.classList.add("invalid");
      field?.insertAdjacentHTML("beforeend", `<span class="error">${esc(input.dataset.msg || "Preencha este campo.")}</span>`);
      first ||= input;
    }
  });
  first?.focus();
  return !first;
}

function wireSimpleForm(form, endpoint, transform = (d) => d) {
  const box = form.querySelector(".notice") || form.insertAdjacentElement("afterbegin", document.createElement("div"));
  box.hidden = true;
  box.setAttribute("role", "status");
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    if (!validate(form)) return;
    const btn = form.querySelector('[type="submit"]');
    btn.disabled = true;
    try {
      const res = await api(endpoint, { method: "POST", body: JSON.stringify(transform(formData(form))) });
      form.reset();
      showNotice(box, "ok", res.message);
    } catch (err) {
      showNotice(box, "err", err.message);
    } finally {
      btn.disabled = false;
    }
  });
}

/* máscara de telefone (xx) xxxxx-xxxx */
function maskPhone(input) {
  input.addEventListener("input", () => {
    const d = input.value.replace(/\D/g, "").slice(0, 11);
    input.value = d.length <= 2 ? d : d.length <= 6 ? `(${d.slice(0, 2)}) ${d.slice(2)}`
      : d.length <= 10 ? `(${d.slice(0, 2)}) ${d.slice(2, 6)}-${d.slice(6)}`
      : `(${d.slice(0, 2)}) ${d.slice(2, 7)}-${d.slice(7)}`;
  });
}

/* ---------------------------------------------------------------- páginas */
function workCard(item) {
  const photo = item.image_path
    ? `<img src="${esc(item.image_path)}" alt="${esc(item.title)}" loading="lazy">`
    : icon("photo", "placeholder");
  const meta = [item.brand, item.location, fmtDate(item.happened_on)].filter(Boolean).join(" — ");
  return `<button class="work" type="button" data-id="${item.id}">
      <span class="work-photo">${photo}</span>
      <h3>${esc(item.title)}</h3><span class="meta">${esc(meta)}</span>
    </button>`;
}

function wireLightbox(container, items) {
  let dlg = document.querySelector("dialog.lightbox");
  if (!dlg) {
    dlg = document.createElement("dialog");
    dlg.className = "lightbox";
    document.body.append(dlg);
    dlg.addEventListener("click", (e) => { if (e.target === dlg) dlg.close(); });
  }
  container.addEventListener("click", (e) => {
    const btn = e.target.closest(".work");
    if (!btn) return;
    const it = items.find((i) => i.id == btn.dataset.id);
    dlg.innerHTML = `
      <button class="btn btn-ghost close" type="button" aria-label="Fechar">${icon("close")}</button>
      ${it.image_path ? `<img src="${esc(it.image_path)}" alt="${esc(it.title)}">` : ""}
      <div class="body"><h2>${esc(it.title)}</h2>
        <p class="muted">${esc([it.service?.title, it.brand, it.location, fmtDate(it.happened_on)].filter(Boolean).join(" — "))}</p>
        <p>${esc(it.description)}</p></div>`;
    dlg.querySelector(".close").onclick = () => dlg.close();
    dlg.showModal();
  });
}

function reviewCard(t) {
  return `<figure class="review">
      <div class="stars" aria-label="${t.rating} de 5 estrelas">${"★".repeat(t.rating)}${"☆".repeat(5 - t.rating)}</div>
      <blockquote>${esc(t.text)}</blockquote>
      <figcaption>${esc(t.author)}${t.company ? `<span>${esc(t.company)}</span>` : ""}</figcaption>
    </figure>`;
}

const pages = {
  async home(site) {
    document.querySelector("[data-headline]").textContent = site.headline;
    document.querySelector("[data-intro]").textContent = site.intro;
    if (site.whatsapp) {
      const w = document.querySelector("[data-whats]");
      w.href = whatsLink(site.whatsapp);
      w.hidden = false;
    }
    const [services, works, reviews] = await Promise.all([
      api("/services"), api("/portfolio?featured=true"), api("/testimonials"),
    ]);
    document.querySelector("[data-services]").innerHTML = services.map((s) => `
      <li class="shelf-item">
        <span class="icon">${icon(s.icon)}</span>
        <div><h3>${esc(s.title)}</h3><p>${esc(s.summary)}</p></div>
        <a class="more" href="/servicos#${esc(s.slug)}">Ver detalhes</a>
      </li>`).join("");
    if (works.length) {
      const g = document.querySelector("[data-works]");
      g.innerHTML = works.slice(0, 6).map(workCard).join("");
      wireLightbox(g, works);
      document.querySelector("#trabalhos").hidden = false;
    }
    if (reviews.length) {
      document.querySelector("[data-reviews]").innerHTML = reviews.slice(0, 3).map(reviewCard).join("");
      document.querySelector("#avaliacoes").hidden = false;
    }
  },

  async servicos() {
    const services = await api("/services");
    document.querySelector("[data-services]").innerHTML = services.map((s) => `
      <article class="service-block" id="${esc(s.slug)}">
        <div>${icon(s.icon, "icon")}<h2>${esc(s.title)}</h2><p>${esc(s.description || s.summary)}</p></div>
        <div>
          ${s.includes ? `<h3>O que está incluído</h3><ul class="checklist">${s.includes.split("\n").filter(Boolean).map((i) => `<li>${esc(i)}</li>`).join("")}</ul>` : ""}
          <a class="btn" href="/orcamento?servico=${s.id}">Pedir orçamento deste serviço</a>
        </div>
      </article>`).join("");
    if (location.hash) document.querySelector(location.hash)?.scrollIntoView();
  },

  async portfolio() {
    const [items, services] = await Promise.all([api("/portfolio"), api("/services")]);
    const grid = document.querySelector("[data-works]");
    const chips = document.querySelector("[data-chips]");
    const used = services.filter((s) => items.some((i) => i.service_id === s.id));
    chips.innerHTML = [`<button class="chip" aria-pressed="true" data-s="">Todos</button>`,
      ...used.map((s) => `<button class="chip" aria-pressed="false" data-s="${s.id}">${esc(s.title)}</button>`)].join("");
    const draw = (sid) => {
      const list = sid ? items.filter((i) => i.service_id == sid) : items;
      grid.innerHTML = list.length ? list.map(workCard).join("")
        : `<p class="empty">Os registros das ações aparecem aqui em breve. Enquanto isso, veja os <a href="/servicos">serviços</a>.</p>`;
    };
    chips.addEventListener("click", (e) => {
      const c = e.target.closest(".chip");
      if (!c) return;
      chips.querySelectorAll(".chip").forEach((b) => b.setAttribute("aria-pressed", b === c));
      draw(c.dataset.s);
    });
    draw("");
    wireLightbox(grid, items);
    if (!used.length) chips.hidden = true;
  },

  async sobre(site) {
    document.querySelector("[data-about]").innerHTML = site.about.split(/\n{2,}/).map((p) => `<p>${esc(p)}</p>`).join("");
    document.querySelector("[data-facts]").innerHTML = `
      <div><dt>Razão social</dt><dd>${esc(site.legal_name)}</dd></div>
      <div><dt>CNPJ</dt><dd>${esc(site.cnpj)}</dd></div>
      <div><dt>Formato</dt><dd>MEI — emite nota fiscal de serviço</dd></div>
      <div><dt>Região atendida</dt><dd>${esc(site.region)}</dd></div>`;
    const reviews = await api("/testimonials");
    if (reviews.length) {
      document.querySelector("[data-reviews]").innerHTML = reviews.map(reviewCard).join("");
      document.querySelector("#avaliacoes").hidden = false;
    }
  },

  async contato(site) {
    const list = document.querySelector("[data-channels]");
    const items = [
      site.whatsapp && `<div><dt>WhatsApp</dt><dd><a href="${whatsLink(site.whatsapp)}" target="_blank" rel="noopener">${esc(site.whatsapp)}</a></dd></div>`,
      site.phone && `<div><dt>Telefone</dt><dd><a href="tel:${esc(site.phone.replace(/\D/g, ""))}">${esc(site.phone)}</a></dd></div>`,
      site.email && `<div><dt>E-mail</dt><dd><a href="mailto:${esc(site.email)}">${esc(site.email)}</a></dd></div>`,
      site.instagram && `<div><dt>Instagram</dt><dd>${esc(site.instagram)}</dd></div>`,
      `<div><dt>Região atendida</dt><dd>${esc(site.region)}</dd></div>`,
    ].filter(Boolean).join("");
    list.innerHTML = items;
    const form = document.querySelector("#contact-form");
    maskPhone(form.phone);
    wireSimpleForm(form, "/contact");
  },

  async avaliar() {
    wireSimpleForm(document.querySelector("#review-form"), "/testimonials",
      (d) => ({ ...d, rating: Number(d.rating || 5) }));
  },

  async orcamento() {
    const services = await api("/services");
    const form = document.querySelector("#quote-form");
    const preset = new URLSearchParams(location.search).get("servico");
    form.querySelector("[data-options]").innerHTML = services.map((s) => `
      <div class="option">
        <input type="radio" name="service_id" id="svc-${s.id}" value="${s.id}" ${preset == s.id ? "checked" : ""} required data-msg="Escolha um serviço.">
        <label for="svc-${s.id}">${icon(s.icon)}<span>${esc(s.title)}<small>${esc(s.summary)}</small></span></label>
      </div>`).join("") + `
      <div class="option">
        <input type="radio" name="service_id" id="svc-0" value="">
        <label for="svc-0">${icon("tag")}<span>Ainda não sei<small>Me conte o objetivo e eu sugiro o formato.</small></span></label>
      </div>`;
    maskPhone(form.phone);
    form.event_date.min = new Date().toISOString().slice(0, 10);

    const steps = [...form.querySelectorAll("fieldset[data-step]")];
    const marks = [...document.querySelectorAll(".progress li")];
    const box = form.querySelector(".notice");
    let current = 0;
    const show = (i, focus = true) => {
      current = i;
      steps.forEach((s, n) => (s.hidden = n !== i));
      marks.forEach((m, n) => {
        m.className = n < i ? "done" : n === i ? "current" : "";
        m.toggleAttribute("aria-current", n === i);
      });
      form.querySelector("[data-back]").hidden = i === 0;
      form.querySelector("[data-next]").hidden = i === steps.length - 1;
      form.querySelector('[type="submit"]').hidden = i !== steps.length - 1;
      if (i === steps.length - 1) renderSummary();
      if (focus) steps[i].querySelector("legend")?.focus();
    };
    const renderSummary = () => {
      const d = formData(form);
      const svc = services.find((s) => s.id == d.service_id);
      const rows = [
        ["Serviço", svc ? svc.title : "A definir"], ["Local", [d.venue_type, d.city].filter(Boolean).join(" em ") || "—"],
        ["Data", d.event_date ? new Date(d.event_date + "T12:00").toLocaleDateString("pt-BR") : "A combinar"],
        ["Duração", `${d.days} dia(s), ${d.hours_per_day} h por dia`], ["Contato", `${d.name} · ${d.phone} · ${d.email}`],
      ];
      form.querySelector("[data-summary]").innerHTML = rows.map(([k, v]) => `<div><strong>${k}</strong><span>${esc(v)}</span></div>`).join("");
    };
    form.querySelector("[data-next]").addEventListener("click", () => {
      if (!validate(steps[current])) return; // valida apenas a etapa visível
      show(current + 1);
    });
    form.querySelector("[data-back]").addEventListener("click", () => show(current - 1));
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      if (!validate(steps[current])) return;
      const d = formData(form);
      const payload = { ...d, service_id: d.service_id ? Number(d.service_id) : null,
        days: Number(d.days), hours_per_day: Number(d.hours_per_day), event_date: d.event_date || null };
      const btn = form.querySelector('[type="submit"]');
      btn.disabled = true;
      try {
        const res = await api("/quotes", { method: "POST", body: JSON.stringify(payload) });
        form.hidden = true;
        document.querySelector(".progress").hidden = true;
        const done = document.querySelector("[data-done]");
        done.hidden = false;
        done.querySelector("[data-done-msg]").textContent = res.message + ` Número do pedido: ${res.id}.`;
        done.querySelector("h2").focus();
      } catch (err) {
        showNotice(box, "err", err.message);
      } finally {
        btn.disabled = false;
      }
    });
    show(0, false);
  },
};

/* ---------------------------------------------------------------- início */
(async function init() {
  let site = { business_name: "Natalice Alves", business_subtitle: "Promoção de vendas", region: "", cnpj: "", legal_name: "", about: "", headline: "", intro: "" };
  try { site = await api("/site"); } catch { /* segue com o padrão */ }
  renderHeader(site);
  renderFooter(site);
  const page = document.body.dataset.page;
  try {
    await pages[page]?.(site);
  } catch (err) {
    console.error(err);
  }
})();

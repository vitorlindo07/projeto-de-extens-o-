import { ACTION_STATUS, api, dateBR, esc, hhmm, money, MONTHS, pill } from "./core.js";

export function meiMeter(m) {
  const pct = Math.min(m.percent, 120);
  const width = Math.min(pct / 1.2, 100); // a barra vai até 120% (tolerância)
  return `
    <div class="meter ${m.level}" role="meter" aria-valuemin="0" aria-valuemax="${m.limit}" aria-valuenow="${m.revenue}"
         aria-label="Faturamento do MEI em ${m.year}">
      <div class="fill" style="width:${width}%"></div>
      <span class="mark" style="left:${80 / 1.2}%"><span>80%</span></span>
      <span class="mark" style="left:${100 / 1.2}%"><span>limite</span></span>
    </div>
    <div class="meter-legend">
      <span><strong>${money(m.revenue)}</strong> de ${money(m.limit)} (${m.percent}%)</span>
      <span class="muted">${m.remaining >= 0 ? `Faltam ${money(m.remaining)}` : `Passou ${money(-m.remaining)}`}</span>
    </div>
    <p class="small muted" style="margin:.6rem 0 0">${esc(m.message)}
      ${m.proportional ? ` Limite proporcional: ${m.active_months} meses de atividade em ${m.year}.` : ""}
      ${m.monthly_room ? ` Média disponível por mês até dezembro: ${money(m.monthly_room)}.` : ""}</p>`;
}

export async function dashboard(view) {
  const d = await api("/api/admin/dashboard");
  const q = d.quotes_by_status;
  const now = new Date();
  const dasAlert = !d.das_due.paid && now.getDate() >= 10
    ? `<div class="alert warn"><span>O DAS de ${MONTHS[d.das_due.month - 1]} vence dia ${d.das_due.due_day} e ainda não foi marcado como pago.</span>
       <a class="btn btn-sm" href="#/financeiro">Ver DAS</a></div>` : "";
  const dasnAlert = now.getMonth() <= 4
    ? `<div class="alert info"><span>A declaração anual do MEI (DASN-SIMEI) de ${now.getFullYear() - 1} deve ser entregue até 31 de maio.</span>
       <a class="btn btn-sm btn-ghost" href="#/financeiro">Ver faturamento do ano</a></div>` : "";
  const extra = [
    d.unread_messages && `<a href="#/mensagens">${d.unread_messages} mensagem(ns) não lida(s)</a>`,
    d.pending_testimonials && `<a href="#/avaliacoes">${d.pending_testimonials} avaliação(ões) para revisar</a>`,
  ].filter(Boolean).join(" · ");

  view.innerHTML = `
    <div class="view-head"><h1>Visão geral</h1>
      <div class="toolbar"><a class="btn btn-ghost" href="#/agenda/nova">Nova ação</a><a class="btn" href="#/orcamentos">Ver orçamentos</a></div></div>
    ${dasAlert}${dasnAlert}
    ${extra ? `<div class="alert info"><span>${extra}</span></div>` : ""}
    <div class="kpis">
      <div class="kpi"><div class="v">${q.novo || 0}</div><div class="l">orçamentos novos</div></div>
      <div class="kpi"><div class="v">${d.upcoming.length}</div><div class="l">ações nos próximos 14 dias</div></div>
      <div class="kpi"><div class="v">${d.actions_done_year}</div><div class="l">ações realizadas em ${now.getFullYear()}</div></div>
      <div class="kpi"><div class="v">${d.people_reached.toLocaleString("pt-BR")}</div><div class="l">pessoas abordadas (total)</div></div>
    </div>
    <div class="panel"><h2>Limite do MEI em ${d.mei.year}</h2>${meiMeter(d.mei)}</div>
    <div class="grid grid-2" style="margin-top:1rem">
      <section class="panel"><h2>Próximas ações</h2>
        ${d.upcoming.length ? `<ul class="list">${d.upcoming.map((a) => `
          <li><span><a href="#/agenda/${a.id}"><strong>${esc(a.title)}</strong></a><br>
            <span class="small muted">${dateBR(a.date)} ${a.start_time ? `· ${hhmm(a.start_time)}–${hhmm(a.end_time)}` : ""} ${a.location ? `· ${esc(a.location)}` : ""}</span></span>
            ${pill(a.status, ACTION_STATUS)}</li>`).join("")}</ul>`
          : `<p class="muted">Nada agendado para as próximas duas semanas.</p>`}
      </section>
      <section class="panel"><h2>Orçamentos aguardando resposta</h2>
        ${d.new_quotes.length ? `<ul class="list">${d.new_quotes.map((o) => `
          <li><span><a href="#/orcamentos/${o.id}"><strong>${esc(o.company || o.name)}</strong></a><br>
            <span class="small muted">${esc(o.service?.title || "Serviço a definir")} · ${esc(o.city)} · recebido em ${dateBR(o.created_at)}</span></span></li>`).join("")}</ul>`
          : `<p class="muted">Nenhum pedido novo. Os pedidos do site aparecem aqui.</p>`}
        <p class="small muted" style="margin:.8rem 0 0">Taxa de aprovação dos orçamentos: <strong>${d.conversion_rate}%</strong></p>
      </section>
    </div>`;
}

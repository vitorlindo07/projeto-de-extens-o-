/* Painel — roteador por hash e moldura. */
import { $, $$, api, esc, logout, toast } from "./core.js";
import { dashboard } from "./dashboard.js";
import { quotes } from "./quotes.js";
import { agenda } from "./agenda.js";
import { clients } from "./clients.js";
import { finance } from "./finance.js";
import { services, portfolio, reviews, messages } from "./content.js";
import { settingsView } from "./settings.js";

const ROUTES = {
  "": [dashboard, "Visão geral"], orcamentos: [quotes, "Orçamentos"], agenda: [agenda, "Agenda"],
  clientes: [clients, "Clientes"], financeiro: [finance, "Financeiro e MEI"], servicos: [services, "Serviços"],
  portfolio: [portfolio, "Portfólio"], avaliacoes: [reviews, "Avaliações"], mensagens: [messages, "Mensagens"],
  configuracoes: [settingsView, "Configurações"],
};

const view = $("#view");

export async function refreshBadges() {
  try {
    const d = await api("/api/admin/dashboard");
    const set = (key, n) => { const b = $(`[data-badge="${key}"]`); b.textContent = n; b.hidden = !n; };
    set("quotes", d.quotes_by_status.novo || 0);
    set("messages", d.unread_messages);
    set("reviews", d.pending_testimonials);
  } catch { /* silencioso */ }
}

async function route() {
  const [name, ...params] = location.hash.replace(/^#\/?/, "").split("/");
  const [render, title] = ROUTES[name] || ROUTES[""];
  $$(".side nav a").forEach((a) => a.classList.toggle("active", a.getAttribute("href") === `#/${name}`));
  $("#side").classList.remove("open");
  $$("dialog").forEach((d) => { if (d.open) d.close(); d.remove(); }); // fecha janelas da tela anterior
  document.title = `${title} · Painel Natalice`;
  view.innerHTML = `<p class="muted">Carregando…</p>`;
  try {
    await render(view, params);
  } catch (e) {
    view.innerHTML = `<div class="panel"><h2>Não foi possível carregar esta tela</h2><p>${esc(e.message)}</p>
      <button class="btn" onclick="location.reload()">Tentar de novo</button></div>`;
  }
  view.focus({ preventScroll: true });
}

window.addEventListener("hashchange", route);
window.addEventListener("nt:changed", refreshBadges);
$("[data-logout]").addEventListener("click", logout);
$("[data-menu]").addEventListener("click", () => $("#side").classList.toggle("open"));
try {
  const user = JSON.parse(localStorage.getItem("nt_user") || "{}");
  $("[data-user]").innerHTML = `<strong>${esc(user.name || "")}</strong>`;
} catch { /* sem usuário salvo */ }

api("/api/auth/me").then(() => { route(); refreshBadges(); }).catch((e) => toast(e.message, "err"));

/* Conteúdo do site: serviços, portfólio, avaliações e mensagens. */
import { api, confirmDialog, dateBR, dateTimeBR, emptyState, esc, formDialog, invalidate, servicesList, toast, whatsUrl } from "./core.js";

const ICON_OPTIONS = [["cup", "Copo / degustação"], ["gift", "Presente / amostra"], ["flyer", "Folheto"], ["shelf", "Gôndola"],
                      ["tent", "Estande / evento"], ["spark", "Demonstração"], ["tag", "Etiqueta"]];
const changed = () => window.dispatchEvent(new Event("nt:changed"));

/* ---------------------------------------------------------------- serviços */
export async function services(view) {
  view.innerHTML = `<div class="view-head"><h1>Serviços</h1><div class="toolbar"><button class="btn" data-new>Novo serviço</button></div></div>
    <p class="muted" style="margin-top:-.6rem">Aparecem no site na ordem definida aqui. Serviços inativos ficam ocultos.</p>
    <div class="table-wrap" data-table></div>`;
  const draw = async () => {
    invalidate();
    const list = await servicesList(true);
    view.querySelector("[data-table]").innerHTML = list.length ? `<table>
      <thead><tr><th class="num">Ordem</th><th>Serviço</th><th>Resumo</th><th>No site</th></tr></thead>
      <tbody>${list.map((s) => `<tr class="clickable" data-id="${s.id}" tabindex="0"><td class="num">${s.position}</td>
        <td><strong>${esc(s.title)}</strong></td><td>${esc(s.summary)}</td>
        <td>${s.active ? '<span class="pill s-aprovado">Visível</span>' : '<span class="pill">Oculto</span>'}</td></tr>`).join("")}</tbody></table>`
      : emptyState("Nenhum serviço cadastrado.", "Novo serviço", () => edit(null));
    view.querySelectorAll("tr[data-id]").forEach((tr) => {
      tr.onclick = () => edit(list.find((s) => s.id == tr.dataset.id));
      tr.onkeydown = (e) => e.key === "Enter" && tr.onclick();
    });
  };
  const edit = (s) => formDialog({
    title: s ? "Editar serviço" : "Novo serviço", wide: true,
    fields: [
      { name: "title", label: "Nome do serviço", required: true },
      { name: "icon", label: "Ícone", type: "select", options: ICON_OPTIONS },
      { name: "summary", label: "Resumo (uma linha)", required: true, full: true },
      { name: "description", label: "Descrição completa", type: "textarea", rows: 4 },
      { name: "includes", label: "O que está incluído (um item por linha)", type: "textarea", rows: 4 },
      { name: "position", label: "Ordem de exibição", type: "number", min: 0 },
      { name: "active", label: "Mostrar no site", type: "checkbox" },
    ],
    values: s || { active: true, position: 0, icon: "tag" },
    onSubmit: async (v) => {
      await api(s ? `/api/admin/services/${s.id}` : "/api/admin/services", { method: s ? "PUT" : "POST", body: { ...v, position: v.position || 0 } });
      toast("Serviço salvo."); draw();
    },
    onDelete: s ? async () => { await api(`/api/admin/services/${s.id}`, { method: "DELETE" }); toast("Serviço excluído."); draw(); } : null,
  });
  view.querySelector("[data-new]").onclick = () => edit(null);
  await draw();
}

/* ---------------------------------------------------------------- portfólio */
export async function portfolio(view) {
  view.innerHTML = `<div class="view-head"><h1>Portfólio</h1><div class="toolbar"><button class="btn" data-new>Adicionar trabalho</button></div></div>
    <p class="muted" style="margin-top:-.6rem">Fotos de ações realizadas. Peça autorização da loja e da marca antes de publicar fotos com pessoas ou produtos.</p>
    <div data-grid></div>`;
  const draw = async () => {
    const list = await api("/api/admin/portfolio");
    view.querySelector("[data-grid]").innerHTML = list.length ? `<div class="cards">${list.map((p) => `
      <article class="card"><div class="ph">${p.image_path ? `<img src="${esc(p.image_path)}" alt="">` : "Sem foto"}</div>
        <div class="bd"><strong>${esc(p.title)}</strong><br><span class="small muted">${esc([p.brand, p.location, dateBR(p.happened_on)].filter(Boolean).join(" · "))}</span></div>
        <div class="ft">${p.published ? '<span class="pill s-aprovado">Publicado</span>' : '<span class="pill">Rascunho</span>'}
          ${p.featured ? '<span class="pill s-em_analise">Destaque</span>' : ""}
          <button class="btn btn-ghost btn-sm" data-id="${p.id}" style="margin-left:auto">Editar</button></div></article>`).join("")}</div>`
      : emptyState("Nenhum trabalho no portfólio ainda.", "Adicionar trabalho", () => edit(null));
    view.querySelectorAll("[data-id]").forEach((b) => b.onclick = () => edit(list.find((p) => p.id == b.dataset.id)));
  };
  const edit = async (p) => {
    const svcs = await servicesList();
    formDialog({
      title: p ? "Editar trabalho" : "Novo trabalho", wide: true,
      fields: [
        { name: "title", label: "Título", required: true, full: true },
        { name: "brand", label: "Marca / cliente" },
        { name: "service_id", label: "Serviço", type: "select", options: [["", "—"], ...svcs.map((s) => [s.id, s.title])] },
        { name: "happened_on", label: "Data", type: "date" },
        { name: "location", label: "Local" },
        { name: "description", label: "Descrição", type: "textarea", rows: 3 },
        { name: "image", label: p?.image_path ? "Trocar foto (JPG, PNG ou WEBP, até 5 MB)" : "Foto (JPG, PNG ou WEBP, até 5 MB)", type: "file", full: true },
        ...(p?.image_path ? [{ name: "remove_image", label: "Remover a foto atual", type: "checkbox" }] : []),
        { name: "published", label: "Publicar no site", type: "checkbox" },
        { name: "featured", label: "Destacar na página inicial", type: "checkbox" },
      ],
      values: p || { published: true },
      onSubmit: async (v) => {
        const fd = new FormData();
        for (const [k, val] of Object.entries(v)) {
          if (k === "image") { if (val) fd.append("image", val); continue; }
          if (val === null || val === "") continue;
          fd.append(k, typeof val === "boolean" ? String(val) : val);
        }
        await api(p ? `/api/admin/portfolio/${p.id}` : "/api/admin/portfolio", { method: p ? "PUT" : "POST", body: fd });
        toast("Trabalho salvo."); draw();
      },
      onDelete: p ? async () => { await api(`/api/admin/portfolio/${p.id}`, { method: "DELETE" }); toast("Trabalho excluído."); draw(); } : null,
    });
  };
  view.querySelector("[data-new]").onclick = () => edit(null);
  await draw();
}

/* ---------------------------------------------------------------- avaliações */
export async function reviews(view) {
  view.innerHTML = `<div class="view-head"><h1>Avaliações</h1>
      <div class="toolbar"><a class="btn btn-ghost" href="/avaliar" target="_blank" rel="noopener">Abrir página de avaliação</a></div></div>
    <p class="muted" style="margin-top:-.6rem">Envie o link <strong>${esc(location.origin)}/avaliar</strong> para quem contratou. Só aparecem no site as avaliações aprovadas.</p>
    <div data-list></div>`;
  const draw = async () => {
    const list = await api("/api/admin/testimonials");
    view.querySelector("[data-list]").innerHTML = list.length ? list.map((t) => `
      <article class="panel"><div class="view-head" style="margin:0 0 .4rem"><h2 style="margin:0">${esc(t.author)}
        <span class="small muted">${esc(t.company)}</span></h2>
        <span>${"★".repeat(t.rating)}<span class="muted">${"☆".repeat(5 - t.rating)}</span></span></div>
        <p style="margin:.2rem 0 .8rem">${esc(t.text)}</p>
        <div class="toolbar"><span class="small muted">Enviada em ${dateBR(t.created_at)}</span>
          ${t.approved ? '<span class="pill s-aprovado">Publicada</span>' : '<span class="pill s-em_analise">Aguardando revisão</span>'}
          <span style="flex:1"></span>
          <button class="btn btn-sm ${t.approved ? "btn-ghost" : ""}" data-t="${t.id}" data-a="${!t.approved}">${t.approved ? "Ocultar" : "Publicar"}</button>
          <button class="btn btn-sm btn-danger" data-del="${t.id}">Excluir</button></div></article>`).join("")
      : emptyState("Nenhuma avaliação recebida ainda.");
    view.querySelectorAll("[data-t]").forEach((b) => b.onclick = async () => {
      await api(`/api/admin/testimonials/${b.dataset.t}?approved=${b.dataset.a}`, { method: "PATCH" });
      toast(b.dataset.a === "true" ? "Avaliação publicada." : "Avaliação ocultada."); changed(); draw();
    });
    view.querySelectorAll("[data-del]").forEach((b) => b.onclick = async () => {
      if (!(await confirmDialog("Excluir esta avaliação?"))) return;
      await api(`/api/admin/testimonials/${b.dataset.del}`, { method: "DELETE" }); toast("Avaliação excluída."); changed(); draw();
    });
  };
  await draw();
}

/* ---------------------------------------------------------------- mensagens */
export async function messages(view) {
  view.innerHTML = `<div class="view-head"><h1>Mensagens</h1></div><div data-list></div>`;
  const draw = async () => {
    const list = await api("/api/admin/messages");
    view.querySelector("[data-list]").innerHTML = list.length ? list.map((m) => `
      <article class="panel" style="${m.read ? "" : "border-left:4px solid var(--tag-deep)"}">
        <div class="view-head" style="margin:0 0 .4rem"><h2 style="margin:0">${esc(m.name)}</h2><span class="small muted">${dateTimeBR(m.created_at)}</span></div>
        <p class="small muted" style="margin:0 0 .5rem"><a href="mailto:${esc(m.email)}">${esc(m.email)}</a> ${m.phone ? `· ${esc(m.phone)}` : ""}</p>
        <p style="white-space:pre-wrap;margin:0 0 .8rem">${esc(m.message)}</p>
        <div class="toolbar">
          <a class="btn btn-sm" href="mailto:${esc(m.email)}?subject=${encodeURIComponent("Re: contato pelo site")}">Responder por e-mail</a>
          ${m.phone ? `<a class="btn btn-sm btn-ghost" href="${whatsUrl(m.phone)}" target="_blank" rel="noopener">WhatsApp</a>` : ""}
          <button class="btn btn-sm btn-ghost" data-r="${m.id}" data-v="${!m.read}">${m.read ? "Marcar como não lida" : "Marcar como lida"}</button>
          <button class="btn btn-sm btn-danger" data-del="${m.id}">Excluir</button></div></article>`).join("")
      : emptyState("Nenhuma mensagem. As mensagens do formulário de contato aparecem aqui.");
    view.querySelectorAll("[data-r]").forEach((b) => b.onclick = async () => {
      await api(`/api/admin/messages/${b.dataset.r}?read=${b.dataset.v}`, { method: "PATCH" }); changed(); draw();
    });
    view.querySelectorAll("[data-del]").forEach((b) => b.onclick = async () => {
      if (!(await confirmDialog("Excluir esta mensagem?"))) return;
      await api(`/api/admin/messages/${b.dataset.del}`, { method: "DELETE" }); toast("Mensagem excluída."); changed(); draw();
    });
  };
  await draw();
}

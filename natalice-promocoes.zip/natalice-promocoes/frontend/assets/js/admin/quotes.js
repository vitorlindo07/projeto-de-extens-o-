import { api, dateBR, esc, formDialog, infoDialog, isoToday, money, pill, QUOTE_STATUS, toast, whatsUrl,
         confirmDialog, emptyState } from "./core.js";

let filter = "";

export async function quotes(view, [openId]) {
  const draw = async () => {
    const search = view.querySelector("[data-q]")?.value || "";
    const list = await api(`/api/admin/quotes?status=${filter}&q=${encodeURIComponent(search)}`);
    view.querySelector("[data-table]").innerHTML = list.length ? `
      <table><thead><tr><th>Recebido</th><th>Cliente</th><th>Serviço</th><th>Cidade / data</th><th class="num">Valor proposto</th><th>Situação</th></tr></thead>
      <tbody>${list.map((q) => `<tr class="clickable" data-id="${q.id}" tabindex="0">
        <td>${dateBR(q.created_at)}</td>
        <td><strong>${esc(q.company || q.name)}</strong>${q.company ? `<br><span class="small muted">${esc(q.name)}</span>` : ""}</td>
        <td>${esc(q.service?.title || "A definir")}</td>
        <td>${esc(q.city)}<br><span class="small muted">${q.event_date ? dateBR(q.event_date) : "sem data"} · ${q.days} dia(s)</span></td>
        <td class="num">${q.proposed_value ? money(q.proposed_value) : "—"}</td>
        <td>${pill(q.status, QUOTE_STATUS)}</td></tr>`).join("")}</tbody></table>`
      : emptyState(filter || search ? "Nenhum orçamento com esse filtro." : "Os pedidos enviados pelo site aparecem aqui.");
    view.querySelectorAll("tr[data-id]").forEach((tr) => {
      const open = () => openQuote(list.find((q) => q.id == tr.dataset.id), draw);
      tr.addEventListener("click", open);
      tr.addEventListener("keydown", (e) => e.key === "Enter" && open());
    });
  };

  view.innerHTML = `
    <div class="view-head"><h1>Orçamentos</h1>
      <div class="toolbar"><input class="input search" type="search" placeholder="Buscar por nome, empresa ou cidade" data-q aria-label="Buscar"></div></div>
    <div class="tabs" role="group" aria-label="Filtrar por situação">
      ${[["", "Todos"], ...Object.entries(QUOTE_STATUS)].map(([k, l]) =>
        `<button class="tab" data-s="${k}" aria-pressed="${filter === k}">${l}</button>`).join("")}
    </div>
    <div class="table-wrap" data-table></div>`;
  view.querySelectorAll(".tab").forEach((t) => t.addEventListener("click", () => {
    filter = t.dataset.s;
    view.querySelectorAll(".tab").forEach((x) => x.setAttribute("aria-pressed", x === t));
    draw();
  }));
  let timer;
  view.querySelector("[data-q]").addEventListener("input", () => { clearTimeout(timer); timer = setTimeout(draw, 250); });
  await draw();
  if (openId) {
    const q = await api(`/api/admin/quotes/${openId}`).catch(() => null);
    if (q) openQuote(q, draw);
  }
}

function openQuote(q, reload) {
  const msg = `Olá, ${q.name.split(" ")[0]}! Aqui é a Natalice. Recebi seu pedido de orçamento (${q.service?.title || "ação promocional"}) pelo site.`;
  const html = `
    <dl class="detail-list">
      <dt>Contato</dt><dd>${esc(q.name)}${q.company ? ` — ${esc(q.company)}` : ""}</dd>
      <dt>E-mail</dt><dd><a href="mailto:${esc(q.email)}">${esc(q.email)}</a></dd>
      <dt>Telefone</dt><dd>${esc(q.phone)}</dd>
      <dt>Serviço</dt><dd>${esc(q.service?.title || "A definir")}</dd>
      <dt>Local</dt><dd>${esc([q.venue_type, q.city].filter(Boolean).join(" em "))}</dd>
      <dt>Data</dt><dd>${q.event_date ? dateBR(q.event_date) : "A combinar"} · ${q.days} dia(s) × ${q.hours_per_day} h</dd>
      <dt>Detalhes</dt><dd>${esc(q.details) || "—"}</dd>
      <dt>Recebido em</dt><dd>${dateBR(q.created_at)} · pedido nº ${q.id}</dd>
    </dl>
    <form class="form-grid" data-edit>
      <div class="f"><label for="q-status">Situação</label><select class="input" id="q-status" name="status">
        ${Object.entries(QUOTE_STATUS).map(([k, l]) => `<option value="${k}" ${q.status === k ? "selected" : ""}>${l}</option>`).join("")}</select></div>
      <div class="f"><label for="q-val">Valor proposto (R$)</label>
        <input class="input" type="number" step="0.01" min="0" id="q-val" name="proposed_value" value="${q.proposed_value ?? ""}"></div>
      <div class="f full"><label for="q-notes">Anotações internas</label>
        <textarea class="input" id="q-notes" name="admin_notes" rows="3">${esc(q.admin_notes)}</textarea></div>
    </form>`;
  const dlg = infoDialog({
    title: `Orçamento — ${q.company || q.name}`, wide: true, html,
    actions: [
      { label: "Salvar alterações", cls: "", onClick: async () => {
        const f = dlg.querySelector("[data-edit]");
        await api(`/api/admin/quotes/${q.id}`, { method: "PATCH", body: {
          status: f.status.value, admin_notes: f.admin_notes.value,
          proposed_value: f.proposed_value.value === "" ? null : Number(f.proposed_value.value) } });
        toast("Orçamento atualizado.");
        window.dispatchEvent(new Event("nt:changed"));
        reload();
      } },
      { label: "Responder no WhatsApp", href: whatsUrl(q.phone, msg) },
      { label: "Transformar em ação", cls: "btn-tag", onClick: () => { convert(q, reload); } },
      { label: "Excluir", cls: "btn-danger", onClick: async () => {
        if (!(await confirmDialog("Excluir este pedido de orçamento?"))) return false;
        await api(`/api/admin/quotes/${q.id}`, { method: "DELETE" });
        toast("Orçamento excluído.");
        reload();
      } },
    ],
  });
}

function convert(q, reload) {
  formDialog({
    title: "Transformar em ação na agenda",
    intro: `<p class="muted">Cria o cliente (se ainda não existir), marca o orçamento como aprovado e coloca a ação na agenda como confirmada.</p>`,
    fields: [
      { name: "date", label: "Data da ação", type: "date", required: true },
      { name: "price", label: "Valor combinado (R$)", type: "money" },
      { name: "title", label: "Título", full: true },
      { name: "location", label: "Local", full: true },
    ],
    values: { date: q.event_date || isoToday(), price: q.proposed_value,
              title: `${q.service?.title || "Ação promocional"} – ${q.company || q.name}`, location: q.city },
    submitLabel: "Criar ação",
    onSubmit: async (v) => {
      const a = await api(`/api/admin/quotes/${q.id}/convert`, { method: "POST", body: v });
      toast("Ação criada na agenda.");
      window.dispatchEvent(new Event("nt:changed"));
      location.hash = `#/agenda/${a.id}`;
    },
  });
}

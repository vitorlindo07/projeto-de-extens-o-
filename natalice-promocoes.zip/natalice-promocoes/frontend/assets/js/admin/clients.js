import { ACTION_STATUS, api, dateBR, emptyState, esc, formDialog, infoDialog, money, pill, toast, whatsUrl } from "./core.js";
import { openAction } from "./agenda.js";

const FIELDS = [
  { name: "name", label: "Pessoa de contato", required: true },
  { name: "company", label: "Empresa / marca / agência" },
  { name: "email", label: "E-mail", type: "email" },
  { name: "phone", label: "Telefone / WhatsApp", type: "tel" },
  { name: "document", label: "CNPJ ou CPF", hint: "Para emitir a nota fiscal." },
  { name: "city", label: "Cidade" },
  { name: "notes", label: "Observações", type: "textarea", rows: 3 },
];

export async function clients(view) {
  view.innerHTML = `
    <div class="view-head"><h1>Clientes</h1>
      <div class="toolbar"><input class="input search" type="search" placeholder="Buscar cliente" data-q aria-label="Buscar cliente">
        <button class="btn" data-new>Novo cliente</button></div></div>
    <div class="table-wrap" data-table></div>`;
  const draw = async () => {
    const q = view.querySelector("[data-q]").value;
    const list = await api(`/api/admin/clients?q=${encodeURIComponent(q)}`);
    view.querySelector("[data-table]").innerHTML = list.length ? `<table>
      <thead><tr><th>Empresa</th><th>Contato</th><th>Telefone</th><th>Cidade</th><th>Desde</th></tr></thead>
      <tbody>${list.map((c) => `<tr class="clickable" data-id="${c.id}" tabindex="0">
        <td><strong>${esc(c.company || "—")}</strong></td><td>${esc(c.name)}<br><span class="small muted">${esc(c.email)}</span></td>
        <td>${esc(c.phone)}</td><td>${esc(c.city)}</td><td>${dateBR(c.created_at)}</td></tr>`).join("")}</tbody></table>`
      : emptyState(q ? "Nenhum cliente encontrado." : "Cadastre o primeiro cliente ou transforme um orçamento aprovado em ação.",
                   q ? "" : "Novo cliente", () => edit(null, draw));
    view.querySelectorAll("tr[data-id]").forEach((tr) => {
      tr.addEventListener("click", () => detail(tr.dataset.id, draw));
      tr.addEventListener("keydown", (e) => e.key === "Enter" && detail(tr.dataset.id, draw));
    });
  };
  view.querySelector("[data-new]").onclick = () => edit(null, draw);
  let t;
  view.querySelector("[data-q]").addEventListener("input", () => { clearTimeout(t); t = setTimeout(draw, 250); });
  await draw();
}

function edit(c, reload) {
  formDialog({
    title: c ? "Editar cliente" : "Novo cliente", fields: FIELDS, values: c || {},
    onSubmit: async (v) => {
      await api(c ? `/api/admin/clients/${c.id}` : "/api/admin/clients", { method: c ? "PUT" : "POST", body: v });
      toast(c ? "Cliente atualizado." : "Cliente cadastrado.");
      reload();
    },
    onDelete: c ? async () => { await api(`/api/admin/clients/${c.id}`, { method: "DELETE" }); toast("Cliente excluído."); reload(); } : null,
  });
}

async function detail(id, reload) {
  const [c, actions] = await Promise.all([api(`/api/admin/clients/${id}`), api(`/api/admin/clients/${id}/actions`)]);
  infoDialog({
    title: c.company || c.name, wide: true,
    html: `<dl class="detail-list">
        <dt>Contato</dt><dd>${esc(c.name)}</dd><dt>E-mail</dt><dd>${esc(c.email) || "—"}</dd>
        <dt>Telefone</dt><dd>${esc(c.phone) || "—"}</dd><dt>CNPJ / CPF</dt><dd>${esc(c.document) || "—"}</dd>
        <dt>Cidade</dt><dd>${esc(c.city) || "—"}</dd><dt>Observações</dt><dd>${esc(c.notes) || "—"}</dd>
        <dt>Ações</dt><dd>${c.total_actions}</dd><dt>Total faturado</dt><dd><strong>${money(c.total_billed)}</strong></dd></dl>
      <h3>Histórico de ações</h3>
      ${actions.length ? `<ul class="list">${actions.map((a) => `<li><span>${dateBR(a.date)} — ${esc(a.title)}</span>
        <span>${money(a.price)} ${pill(a.status, ACTION_STATUS)}</span></li>`).join("")}</ul>` : `<p class="muted">Nenhuma ação ainda.</p>`}`,
    actions: [
      { label: "Editar", cls: "", onClick: () => edit(c, reload) },
      { label: "Agendar ação", onClick: () => openAction({ client_id: c.id, title: `Ação – ${c.company || c.name}`, location: c.city }) },
      ...(c.phone ? [{ label: "WhatsApp", href: whatsUrl(c.phone) }] : []),
    ],
  });
}

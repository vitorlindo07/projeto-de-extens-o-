import { ACTION_STATUS, api, clientsList, dateBR, emptyState, esc, formDialog, hhmm, isoToday, money, MONTHS, pill,
         servicesList, toast } from "./core.js";

const monthStart = (d = new Date()) => new Date(d.getFullYear(), d.getMonth(), 1);
let cursor = monthStart();
let mode = "mes";
const COLORS = { agendada: "#e7efff", confirmada: "#efe6ff", realizada: "#e3f4e7", cancelada: "#fde8e8" };

const iso = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;

export async function agenda(view, [param]) {
  view.innerHTML = `
    <div class="view-head"><h1>Agenda</h1>
      <div class="toolbar">
        <div class="tabs" style="margin:0" role="group" aria-label="Modo de exibição">
          <button class="tab" data-mode="mes" aria-pressed="${mode === "mes"}">Mês</button>
          <button class="tab" data-mode="lista" aria-pressed="${mode === "lista"}">Lista</button></div>
        <button class="btn" data-new>Nova ação</button></div></div>
    <div class="cal-head" style="margin-bottom:.8rem">
      <button class="btn btn-ghost btn-sm" data-prev aria-label="Mês anterior">‹</button>
      <h2 data-title></h2>
      <button class="btn btn-ghost btn-sm" data-next aria-label="Próximo mês">›</button>
      <button class="btn btn-ghost btn-sm" data-today>Hoje</button>
    </div>
    <div data-body></div>`;

  const draw = async () => {
    const first = new Date(cursor);
    const last = new Date(cursor.getFullYear(), cursor.getMonth() + 1, 0);
    view.querySelector("[data-title]").textContent = `${MONTHS[cursor.getMonth()][0].toUpperCase()}${MONTHS[cursor.getMonth()].slice(1)} de ${cursor.getFullYear()}`;
    // inclui os dias das semanas vizinhas visíveis no calendário
    const start = new Date(first); start.setDate(1 - first.getDay());
    const end = new Date(last); end.setDate(last.getDate() + (6 - last.getDay()));
    const list = await api(`/api/admin/actions?start=${iso(mode === "mes" ? start : first)}&end=${iso(mode === "mes" ? end : last)}`);
    const body = view.querySelector("[data-body]");
    if (mode === "lista") {
      body.innerHTML = list.length ? `<div class="table-wrap"><table>
        <thead><tr><th>Data</th><th>Ação</th><th>Cliente</th><th>Local</th><th class="num">Valor</th><th>Situação</th></tr></thead>
        <tbody>${list.map((a) => `<tr class="clickable" data-id="${a.id}" tabindex="0">
          <td>${dateBR(a.date)}<br><span class="small muted">${hhmm(a.start_time)}${a.end_time ? "–" + hhmm(a.end_time) : ""}</span></td>
          <td><strong>${esc(a.title)}</strong><br><span class="small muted">${esc(a.service?.title || "")}</span></td>
          <td>${esc(a.client ? a.client.company || a.client.name : "—")}</td><td>${esc(a.location)}</td>
          <td class="num">${money(a.price)}</td><td>${pill(a.status, ACTION_STATUS)}</td></tr>`).join("")}</tbody></table></div>`
        : emptyState("Nenhuma ação neste mês.", "Agendar ação", () => openAction(null, draw));
      body.querySelectorAll("tr[data-id]").forEach((tr) => {
        const open = () => openAction(list.find((a) => a.id == tr.dataset.id), draw);
        tr.addEventListener("click", open);
        tr.addEventListener("keydown", (e) => e.key === "Enter" && open());
      });
      return;
    }
    const today = isoToday();
    const days = [];
    for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) days.push(new Date(d));
    body.innerHTML = `<div class="calendar">
      ${["dom", "seg", "ter", "qua", "qui", "sex", "sáb"].map((d) => `<div class="dow">${d}</div>`).join("")}
      ${days.map((d) => {
        const key = iso(d);
        const evs = list.filter((a) => a.date === key);
        return `<div class="day ${d.getMonth() !== cursor.getMonth() ? "other" : ""} ${key === today ? "today" : ""}" data-day="${key}">
          <span class="n">${d.getDate()}</span>
          ${evs.map((a) => `<button class="ev" data-id="${a.id}" style="background:${COLORS[a.status]}"
             title="${esc(a.title)}">${hhmm(a.start_time)} ${esc(a.title)}</button>`).join("")}</div>`;
      }).join("")}</div>
      <p class="small muted" style="margin-top:.6rem">Clique em um dia para agendar. ${Object.entries(ACTION_STATUS).map(([k, l]) =>
        `<span class="pill s-${k}">${l}</span>`).join(" ")}</p>`;
    body.querySelectorAll(".day").forEach((cell) => cell.addEventListener("click", (e) => {
      const ev = e.target.closest(".ev");
      if (ev) openAction(list.find((a) => a.id == ev.dataset.id), draw);
      else openAction({ date: cell.dataset.day }, draw);
    }));
  };

  view.querySelector("[data-prev]").onclick = () => { cursor.setMonth(cursor.getMonth() - 1); draw(); };
  view.querySelector("[data-next]").onclick = () => { cursor.setMonth(cursor.getMonth() + 1); draw(); };
  view.querySelector("[data-today]").onclick = () => { cursor = monthStart(); draw(); };
  view.querySelector("[data-new]").onclick = () => openAction(null, draw);
  view.querySelectorAll("[data-mode]").forEach((b) => b.onclick = () => {
    mode = b.dataset.mode;
    view.querySelectorAll("[data-mode]").forEach((x) => x.setAttribute("aria-pressed", x === b));
    draw();
  });
  await draw();

  if (param === "nova") openAction(null, draw);
  else if (param) {
    const a = await api(`/api/admin/actions/${param}`).catch(() => null);
    if (a) {
      const d = new Date(a.date + "T12:00"); cursor = new Date(d.getFullYear(), d.getMonth(), 1);
      await draw();
      openAction(a, draw);
    }
  }
}

export async function openAction(a, reload) {
  const [services, clients] = await Promise.all([servicesList(), clientsList(true)]);
  const isNew = !a?.id;
  const fields = [
    { name: "title", label: "Título", required: true, full: true },
    { name: "client_id", label: "Cliente", type: "select", nullable: true,
      options: [["", "Sem cliente"], ...clients.map((c) => [c.id, c.company ? `${c.company} (${c.name})` : c.name])] },
    { name: "service_id", label: "Serviço", type: "select", nullable: true,
      options: [["", "—"], ...services.map((s) => [s.id, s.title])] },
    { name: "date", label: "Data", type: "date", required: true },
    { name: "status", label: "Situação", type: "select", options: Object.entries(ACTION_STATUS) },
    { name: "start_time", label: "Início", type: "time" },
    { name: "end_time", label: "Término", type: "time" },
    { name: "location", label: "Local (loja, endereço)", full: true },
    { name: "price", label: "Valor combinado (R$)", type: "money" },
    { name: "notes", label: "Observações", type: "textarea", rows: 3 },
    { section: "Relatório pós-ação" },
    { name: "report_people", label: "Pessoas abordadas", type: "number", min: 0 },
    { name: "report_samples", label: "Amostras / panfletos entregues", type: "number", min: 0 },
    { name: "report_notes", label: "Comentários do público e observações", type: "textarea", rows: 3 },
  ];
  const values = { status: "agendada", price: 0, date: isoToday(), ...a,
    start_time: hhmm(a?.start_time), end_time: hhmm(a?.end_time) };
  const save = async (v) => {
    const body = { ...v, client_id: v.client_id ? Number(v.client_id) : null, service_id: v.service_id ? Number(v.service_id) : null,
                   price: v.price || 0, quote_id: a?.quote_id ?? null };
    return isNew ? api("/api/admin/actions", { method: "POST", body })
      : api(`/api/admin/actions/${a.id}`, { method: "PUT", body });
  };
  formDialog({
    title: isNew ? "Nova ação" : "Editar ação", fields, values, wide: true,
    onSubmit: async (v) => { await save(v); toast(isNew ? "Ação agendada." : "Ação atualizada."); reload?.(); },
    onDelete: isNew ? null : async () => { await api(`/api/admin/actions/${a.id}`, { method: "DELETE" }); toast("Ação excluída."); reload?.(); },
    extra: isNew ? [] : [
      { label: "Lançar receita", onClick: async (v) => {
        await save(v);
        await api(`/api/admin/actions/${a.id}/bill`, { method: "POST" });
        toast("Receita lançada no financeiro como pendente.");
        reload?.();
      } },
      { label: "Imprimir relatório", onClick: (v) => { printReport({ ...a, ...v }, clients, services); return false; } },
    ],
  });
}

function printReport(a, clients, services) {
  const c = clients.find((x) => x.id == a.client_id);
  const s = services.find((x) => x.id == a.service_id);
  const w = window.open("", "_blank");
  w.document.write(`<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><title>Relatório – ${esc(a.title)}</title>
    <style>body{font-family:Arial,sans-serif;color:#1b2559;max-width:720px;margin:2rem auto;padding:0 1rem}
    h1{font-size:1.5rem;border-bottom:4px solid #ffd43b;padding-bottom:.4rem}table{width:100%;border-collapse:collapse}
    td{padding:.5rem;border-bottom:1px solid #ddd;vertical-align:top}td:first-child{width:38%;color:#555}</style></head><body>
    <h1>Relatório de ação promocional</h1>
    <table>
      <tr><td>Ação</td><td>${esc(a.title)}</td></tr>
      <tr><td>Cliente</td><td>${esc(c ? c.company || c.name : "—")}</td></tr>
      <tr><td>Serviço</td><td>${esc(s?.title || "—")}</td></tr>
      <tr><td>Data e horário</td><td>${dateBR(a.date)} ${a.start_time ? `das ${hhmm(a.start_time)} às ${hhmm(a.end_time)}` : ""}</td></tr>
      <tr><td>Local</td><td>${esc(a.location || "—")}</td></tr>
      <tr><td>Pessoas abordadas</td><td>${a.report_people ?? "—"}</td></tr>
      <tr><td>Amostras / panfletos entregues</td><td>${a.report_samples ?? "—"}</td></tr>
      <tr><td>Comentários e observações</td><td>${esc(a.report_notes || "—").replace(/\n/g, "<br>")}</td></tr>
    </table>
    <p style="margin-top:2rem;font-size:.9rem;color:#555">Natalice Alves · Promoção de vendas</p>
    <script>window.print()<\/script></body></html>`);
  w.document.close();
}

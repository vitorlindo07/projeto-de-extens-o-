# Natalice Alves · Promoção de Vendas

Site institucional e sistema de gestão para uma microempreendedora individual (MEI) que trabalha com
**promoção de vendas** (CNAE 7319-0/02): degustação, distribuição de amostras, panfletagem,
merchandising no ponto de venda e apoio em eventos.

Projeto de extensão do curso de **Análise e Desenvolvimento de Sistemas (UNIP)**: uma solução
completa (front-end, back-end e banco de dados) desenvolvida para um negócio real da comunidade.

![Página inicial](docs/telas/site-inicio.png)

## O que o sistema faz

**Site público** (para quem contrata)
- Página inicial, serviços, portfólio com filtro e ampliação de fotos, sobre, contato e política de privacidade (LGPD)
- Pedido de orçamento em 4 etapas, com validação, máscara de telefone e resumo antes de enviar
- Página de avaliação para clientes; avaliações só aparecem depois de aprovadas
- Botão de WhatsApp, layout responsivo, navegação por teclado e respeito a "reduzir movimento"

**Painel administrativo** (para a empreendedora)
- **Visão geral**: orçamentos novos, próximas ações, pessoas abordadas, alerta de DAS e da declaração anual
- **Orçamentos**: funil por situação, anotações, resposta direta pelo WhatsApp e conversão em ação com um clique
- **Agenda**: calendário mensal e lista, relatório pós-ação (público abordado, amostras) com versão para impressão
- **Clientes**: cadastro, busca, histórico de ações e total faturado por cliente
- **Financeiro e MEI**: receitas e despesas, gráfico mensal, exportação para planilha, **medidor do limite do MEI**
  (inclusive proporcional ao ano de abertura) e controle do **DAS** mês a mês
- **Conteúdo do site**: serviços, portfólio com envio de fotos, moderação de avaliações, mensagens de contato
- **Configurações**: textos, contatos, dados da empresa, limites do MEI por ano, troca de senha e histórico de atividades

## Tecnologias

| Camada | Escolha | Por quê |
|---|---|---|
| Back-end | Python 3.12 · FastAPI | API tipada, validação automática e documentação em `/docs` |
| Banco | SQLite (padrão) · SQLAlchemy 2.0 | Zero configuração para uma MEI; troca para PostgreSQL só mudando `DATABASE_URL` |
| Autenticação | JWT (PyJWT) + bcrypt | Senha com hash, sessão com validade |
| Front-end | HTML, CSS e JavaScript (módulos ES) | Sem etapa de build; leve e fácil de hospedar |
| Testes | pytest + TestClient | 15 testes cobrindo regras de negócio e segurança |
| Implantação | Docker / docker-compose | Um comando para subir em qualquer servidor |

Segurança: limite de tentativas no login e nos formulários, campo-armadilha contra robôs, validação de
imagem pelo conteúdo do arquivo (não pela extensão), cabeçalhos de segurança, consentimento LGPD e
registro de auditoria das alterações no painel.

## Como rodar

```bash
cd backend
python -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python -m app.seed --demo        # opcional: dados fictícios para demonstração
uvicorn app.main:app --reload
```

- Site: http://localhost:8000
- Painel: http://localhost:8000/admin (primeiro acesso: `admin@natalice.com.br` / `Trocar@123`; troque a senha)
- Documentação da API: http://localhost:8000/docs

Com Docker: `cp .env.example .env` (preencha `SECRET_KEY` e a senha inicial) e `docker compose up -d`.

Testes: `cd backend && pytest -q`

> `--demo` cria clientes, ações e lançamentos **fictícios** marcados como "(exemplo)". Não use no site de produção.

## Estrutura

```
backend/
  app/
    main.py            aplicação, páginas e arquivos estáticos
    models.py          modelo de dados (11 tabelas)
    schemas.py         validação de entrada/saída
    security.py        senha, token e limite de requisições
    site_settings.py   configurações editáveis
    seed.py            dados iniciais
    routers/           public, auth, content, crm, agenda, finance, dashboard
  tests/
frontend/
  *.html               páginas do site
  admin/               login e painel (SPA com rotas por hash)
  assets/css, js       estilos e scripts
docs/                  modelo de dados, manual, relatório de extensão, telas
```

## Documentação

- [Modelo de dados](docs/MODELO_DE_DADOS.md)
- [Manual de uso do painel](docs/MANUAL_DO_PAINEL.md)
- [Publicação (deploy)](docs/DEPLOY.md)
- [Relatório do projeto de extensão](docs/RELATORIO_EXTENSAO.md)

## Telas

| Painel | Financeiro e MEI |
|---|---|
| ![Visão geral](docs/telas/painel-visao-geral.png) | ![Financeiro](docs/telas/painel-financeiro.png) |
| **Agenda** | **Orçamento** |
| ![Agenda](docs/telas/painel-agenda.png) | ![Orçamento](docs/telas/painel-orcamento.png) |

---
Desenvolvido por Erik Junior · [Codex Web](https://codexweb.com.br)
